// ===== Cenário 3D low-poly (ilha, cercado, estrada, vegetação) =====
import * as THREE from 'three';
import { textPlane, checkerTexture } from './models.js';

export const S = 0.05;                    // 1 unidade 3D = 20 px do jogo
export const X = x => x * S;
export const Z = y => y * S;

// ---------- utilidades ----------
let seed = 12345;
const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
const rr = (a, b) => a + rnd() * (b - a);

function canvasTex(w, h, draw, rx, ry) {
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  draw(c.getContext('2d'), w, h);
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(rx || 1, ry || 1);
  t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4;
  return t;
}
function speckle(g, w, h, n, cols, min, max) {
  for (let i = 0; i < n; i++) { g.fillStyle = cols[(rnd() * cols.length) | 0]; const s = rr(min, max); g.fillRect(rnd() * w, rnd() * h, s, s); }
}
const grassTex = (rep) => canvasTex(256, 256, (g, w, h) => {
  g.fillStyle = '#54b45d'; g.fillRect(0, 0, w, h);
  for (let i = 0; i < 14; i++) { g.fillStyle = 'rgba(30,110,50,0.13)'; g.beginPath(); g.arc(rnd() * w, rnd() * h, rr(18, 46), 0, 6.28); g.fill(); }
  for (let i = 0; i < 1500; i++) {
    g.strokeStyle = ['#3f9a4c', '#6acb6d', '#4aa855', '#7bd777', '#38904a'][(rnd() * 5) | 0]; g.lineWidth = 1.5;
    const x = rnd() * w, y = rnd() * h; g.beginPath(); g.moveTo(x, y); g.lineTo(x + rr(-2, 2), y - rr(3, 8)); g.stroke();
  }
}, rep, rep);
const sandTex = (rep) => canvasTex(128, 128, (g, w, h) => {
  g.fillStyle = '#ecd392'; g.fillRect(0, 0, w, h); speckle(g, w, h, 500, ['#d9bd78', '#f6e3ad', '#cfae67'], 1, 3);
}, rep, rep);
const roadTex = (rx, ry) => canvasTex(256, 512, (g, w, h) => {
  g.fillStyle = '#4a4e57'; g.fillRect(0, 0, w, h);
  speckle(g, w, h, 1600, ['#3d4048', '#5a5f69', '#454952', '#666b75'], 1, 3);
  for (let i = 0; i < 6; i++) { g.fillStyle = 'rgba(20,20,25,0.12)'; g.beginPath(); g.ellipse(rnd() * w, rnd() * h, rr(14, 40), rr(10, 30), 0, 0, 6.28); g.fill(); }
  g.fillStyle = '#e9e9e4'; g.fillRect(10, 0, 7, h); g.fillRect(w - 17, 0, 7, h);              // faixas laterais
  g.fillStyle = '#f2c230'; for (let y = 20; y < h; y += 128) g.fillRect(w / 2 - 5, y, 10, 64); // tracejado central
}, rx, ry);
const waterTex = () => canvasTex(256, 256, (g, w, h) => {
  g.fillStyle = '#1b86d3'; g.fillRect(0, 0, w, h);
  for (let i = 0; i < 40; i++) { g.strokeStyle = 'rgba(255,255,255,0.22)'; g.lineWidth = 2; g.beginPath(); const x = rnd() * w, y = rnd() * h; g.arc(x, y, rr(6, 16), 3.6, 5.8); g.stroke(); }
  for (let i = 0; i < 30; i++) { g.fillStyle = 'rgba(10,80,160,0.15)'; g.fillRect(rnd() * w, rnd() * h, rr(10, 30), 3); }
}, 70, 70);
const cobbleTex = () => canvasTex(256, 256, (g, w, h) => {
  g.fillStyle = '#7d7a72'; g.fillRect(0, 0, w, h);
  for (let y = 0; y < h; y += 32) for (let x = (y / 32 % 2) * 20; x < w; x += 40) {
    const l = 60 + rnd() * 40; g.fillStyle = 'rgb(' + (l + 40) + ',' + (l + 36) + ',' + (l + 28) + ')'; g.fillRect(x + 2, y + 2, 36, 28);
  }
}, 2, 5);

const mat = (o) => new THREE.MeshStandardMaterial(Object.assign({ roughness: 0.9, metalness: 0 }, o));

function roundedSlab(x0, z0, x1, z1, r, top, thick, material, parent) {
  const s = new THREE.Shape(), ya = -z0, yb = -z1;
  s.moveTo(x0 + r, yb); s.lineTo(x1 - r, yb); s.quadraticCurveTo(x1, yb, x1, yb + r); s.lineTo(x1, ya - r);
  s.quadraticCurveTo(x1, ya, x1 - r, ya); s.lineTo(x0 + r, ya); s.quadraticCurveTo(x0, ya, x0, ya - r);
  s.lineTo(x0, yb + r); s.quadraticCurveTo(x0, yb, x0 + r, yb);
  const g = new THREE.ExtrudeGeometry(s, { depth: thick, bevelEnabled: false, curveSegments: 8 });
  g.rotateX(-Math.PI / 2);
  const m = new THREE.Mesh(g, material); m.position.y = top - thick; m.receiveShadow = true; parent.add(m); return m;
}
function box(w, h, d, color, x, y, z, parent, o) {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat(Object.assign({ color }, o || {})));
  m.position.set(x, y, z); m.castShadow = true; m.receiveShadow = true; parent.add(m); return m;
}
// px -> 3D
function slab(x0, y0, x1, y1, top, thick, material, parent) {
  const m = new THREE.Mesh(new THREE.BoxGeometry((x1 - x0) * S, thick, (y1 - y0) * S), material);
  m.position.set(X((x0 + x1) / 2), top - thick / 2, Z((y0 + y1) / 2)); m.receiveShadow = true; parent.add(m); return m;
}

// InstancedMesh: itens {x,y,z,s,sx,sy,sz,r,col(THREE.Color)}
export function instanced(geo, material, list, shadows) {
  const im = new THREE.InstancedMesh(geo, material, Math.max(1, list.length));
  const d = new THREE.Object3D();
  list.forEach((it, i) => {
    d.position.set(it.x, it.y, it.z);
    d.scale.set((it.sx || 1) * (it.s || 1), (it.sy || 1) * (it.s || 1), (it.sz || 1) * (it.s || 1));
    d.rotation.set(0, it.r || 0, 0); d.updateMatrix(); im.setMatrixAt(i, d.matrix);
    if (it.col) im.setColorAt(i, it.col);
  });
  im.count = list.length; im.instanceMatrix.needsUpdate = true;
  if (im.instanceColor) im.instanceColor.needsUpdate = true;
  if (shadows) { im.castShadow = true; im.receiveShadow = true; }
  return im;
}
const hsl = (h, s, l) => new THREE.Color().setHSL(h, s, l);
export { grassTex, sandTex, roadTex, waterTex, cobbleTex, mat, roundedSlab, box, slab, rnd, rr, hsl };

// ---------- construção do mapa ----------
export function buildStatic(scene) {
  seed = 777;
  const g = new THREE.Group(); scene.add(g);
  const refs = {};

  // mar animado + espuma na orla
  const wt = waterTex(); refs.water = wt;
  const sea = new THREE.Mesh(new THREE.PlaneGeometry(900, 900), mat({ map: wt, roughness: 0.35, metalness: 0.1 }));
  sea.rotation.x = -Math.PI / 2; sea.position.set(X(700), -0.75, Z(1500)); sea.receiveShadow = true; g.add(sea);
  refs.foam = [];
  for (let i = 0; i < 2; i++) {
    const m = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.35 });
    roundedSlab(60 - 28 - i * 22, 120 - 28 - i * 22, 1340 + 28 + i * 22, 2940 + 28 + i * 22, 300, -0.62 + i * 0.01, 0.05, m, g); refs.foam.push(m);
  }
  // ilha: areia -> grama -> cercado
  roundedSlab(60, 120, 1340, 2940, 300, 0, 1.2, mat({ map: sandTex(1 / 6) }), g);
  roundedSlab(110, 170, 1290, 2890, 240, 0.14, 0.4, mat({ map: grassTex(1 / 7) }), g);
  roundedSlab(200, CFG.penTop, 1200, CFG.penBottom, 60, 0.26, 0.3, mat({ map: grassTex(1 / 7), color: 0xe6ffd8 }), g);
  // acostamento + estrada com faixas
  slab(CFG.laneX - CFG.laneW / 2 - 40, 200, CFG.laneX + CFG.laneW / 2 + 40, CFG.penTop, 0.27, 0.3, mat({ color: 0x9a8a68, roughness: 1 }), g);
  const len = (CFG.penTop - 200) * S, wid = CFG.laneW * S;
  const road = new THREE.Mesh(new THREE.PlaneGeometry(wid, len), mat({ map: roadTex(1, len / 28), roughness: 0.95 }));
  road.rotation.x = -Math.PI / 2; road.position.set(X(CFG.laneX), 0.3, Z((200 + CFG.penTop) / 2)); road.receiveShadow = true; g.add(road);
  // meio-fio alternado nas bordas da estrada
  const curbs = [];
  for (let z = Z(210); z < Z(CFG.penTop) - 1; z += 1.1) for (const sx of [-1, 1]) {
    curbs.push({ x: X(CFG.laneX) + sx * (wid / 2 + 0.3), y: 0.4, z, col: new THREE.Color(Math.floor(z / 1.1) % 2 ? 0xdedbd2 : 0xb23a30) });
  }
  g.add(instanced(new THREE.BoxGeometry(0.55, 0.3, 1.0), mat({ color: 0xffffff }), curbs, true));

  // linha de chegada + arco
  const fl = new THREE.Mesh(new THREE.PlaneGeometry(wid + 2, 2.2), new THREE.MeshBasicMaterial({ map: checkerTexture(16, 2) }));
  fl.rotation.x = -Math.PI / 2; fl.position.set(X(CFG.laneX), 0.33, Z(CFG.finishY)); g.add(fl);
  const ax = wid / 2 + 2.2;
  for (const sx of [-1, 1]) {
    const p = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.6, 9, 10), mat({ color: 0xf4f4f0 })); p.position.set(X(CFG.laneX) + sx * ax, 4.5, Z(CFG.finishY)); p.castShadow = true; g.add(p);
    const cap = new THREE.Mesh(new THREE.SphereGeometry(0.75, 10, 8), mat({ color: 0xe23b3b })); cap.position.set(X(CFG.laneX) + sx * ax, 9.2, Z(CFG.finishY)); g.add(cap);
  }
  box(ax * 2, 0.5, 0.6, 0xe23b3b, X(CFG.laneX), 8.7, Z(CFG.finishY), g);
  const ban = textPlane('🏁 CHEGADA 🏁', ax * 2 - 1, 2.4, '#e23b3b', '#ffffff'); ban.position.set(X(CFG.laneX), 7.3, Z(CFG.finishY) + 0.35); g.add(ban);
  const ban2 = ban.clone(); ban2.rotation.y = Math.PI; ban2.position.z = Z(CFG.finishY) - 0.35; g.add(ban2);
  // bandeirinhas
  const flags = [];
  for (let i = 0; i < 14; i++) flags.push({ x: X(CFG.laneX) - ax + (i + 0.5) * (ax * 2 / 14), y: 6.3 - Math.sin(i / 13 * Math.PI) * 0.0, z: Z(CFG.finishY), col: hsl(i / 14, 0.75, 0.55) });
  const fg = new THREE.ConeGeometry(0.28, 0.7, 3); fg.rotateX(Math.PI);
  g.add(instanced(fg, mat({ color: 0xffffff, side: THREE.DoubleSide }), flags));

  // trilha de pedras do portão até o meio do cercado
  const pathLen = (CFG.penBottom - CFG.finishY) * S * 0.55;
  const path = new THREE.Mesh(new THREE.PlaneGeometry(5, pathLen), mat({ map: cobbleTex() }));
  path.rotation.x = -Math.PI / 2; path.position.set(X(CFG.laneX), 0.58, Z(CFG.finishY) + pathLen / 2 + 1); path.receiveShadow = true; g.add(path);

  // cerca de madeira com tampas
  const posts = [], caps = [];
  const px = (x, y) => { posts.push({ x: X(x), y: 1.0, z: Z(y) }); caps.push({ x: X(x), y: 2.08, z: Z(y) }); };
  const gapL = CFG.laneX - 110, gapR = CFG.laneX + 110;
  for (let x = 200; x <= 1200; x += 34) { if (x > gapL && x < gapR) continue; px(x, CFG.penTop); px(x, CFG.penBottom); }
  for (let y = CFG.penTop + 34; y < CFG.penBottom; y += 34) { px(200, y); px(1200, y); }
  g.add(instanced(new THREE.BoxGeometry(0.36, 2.0, 0.36), mat({ color: 0x8a5a2b }), posts, true));
  g.add(instanced(new THREE.BoxGeometry(0.5, 0.18, 0.5), mat({ color: 0x5e3a18 }), caps, true));
  const rail = 0x9b6a35, ry1 = 0.9, ry2 = 1.55, zc = Z((CFG.penTop + CFG.penBottom) / 2), pd = (CFG.penBottom - CFG.penTop) * S;
  for (const ry of [ry1, ry2]) {
    box((gapL - 200) * S, 0.16, 0.16, rail, X((200 + gapL) / 2), ry, Z(CFG.penTop), g);
    box((1200 - gapR) * S, 0.16, 0.16, rail, X((gapR + 1200) / 2), ry, Z(CFG.penTop), g);
    box(1000 * S, 0.16, 0.16, rail, X(700), ry, Z(CFG.penBottom), g);
    box(0.16, 0.16, pd, rail, X(200), ry, zc, g); box(0.16, 0.16, pd, rail, X(1200), ry, zc, g);
  }
  // tochas no portão
  refs.flames = [];
  for (const sx of [-1, 1]) {
    box(0.4, 3.2, 0.4, 0x4a3320, X(CFG.laneX) + sx * 5.8, 1.6, Z(CFG.finishY) + 0.6, g);
    const fm = new THREE.Mesh(new THREE.SphereGeometry(0.42, 8, 6), new THREE.MeshBasicMaterial({ color: 0xffa530 }));
    fm.position.set(X(CFG.laneX) + sx * 5.8, 3.5, Z(CFG.finishY) + 0.6); g.add(fm); refs.flames.push(fm);
  }
  // celeiro, fardos de feno e placa
  const bx = X(330), bz = Z(2800);
  box(6, 3.6, 5, 0xb23a30, bx, 1.9, bz, g);
  const roof = new THREE.Mesh(new THREE.ConeGeometry(4.8, 2.4, 4), mat({ color: 0x5b3a22 })); roof.rotation.y = Math.PI / 4; roof.scale.set(1.2, 1, 1); roof.position.set(bx, 4.9, bz); roof.castShadow = true; g.add(roof);
  box(1.8, 2.6, 0.12, 0xf3efe2, bx, 1.6, bz - 2.55, g); box(1.8, 0.2, 0.14, 0x5b3a22, bx, 2.9, bz - 2.55, g);
  const hay = new THREE.CylinderGeometry(0.75, 0.75, 1.5, 10); hay.rotateZ(Math.PI / 2);
  g.add(instanced(hay, mat({ color: 0xe0b84a }), [{ x: bx + 4.2, y: 1.0, z: bz - 1, r: 0.3 }, { x: bx + 4.5, y: 1.0, z: bz + 1.2, r: -0.2 }, { x: bx + 4.3, y: 2.3, z: bz + 0.1, r: 0.1 }], true));
  const sign = textPlane('SEU CERCADO', 12, 2.6, '#2e7d32', '#ffffff'); sign.position.set(X(700), 4.4, Z(CFG.penBottom) - 0.5); g.add(sign);
  box(0.3, 4.4, 0.3, 0x6b4a2b, X(700) - 5.6, 2.2, Z(CFG.penBottom) - 0.6, g); box(0.3, 4.4, 0.3, 0x6b4a2b, X(700) + 5.6, 2.2, Z(CFG.penBottom) - 0.6, g);

  // postes de luz ao longo da estrada
  const poles = [], bulbs = [];
  let side = 1;
  for (let y = 400; y < CFG.penTop - 120; y += 340) {
    const x = X(CFG.laneX) + side * (wid / 2 + 1.6); side = -side;
    poles.push({ x, y: 2.3, z: Z(y) }); bulbs.push({ x: x - Math.sign(x - X(CFG.laneX)) * 0.9, y: 4.7, z: Z(y) });
  }
  g.add(instanced(new THREE.CylinderGeometry(0.12, 0.16, 4.6, 6), mat({ color: 0x2c2f38 }), poles, true));
  refs.bulbMat = new THREE.MeshBasicMaterial({ color: 0xfff2b0 });
  g.add(instanced(new THREE.SphereGeometry(0.38, 8, 6), refs.bulbMat, bulbs));

  // grama alta, flores, arbustos e pedras (fora da estrada e do cercado)
  const okSpot = (x, y) => Math.abs(x - CFG.laneX) > CFG.laneW / 2 + 90 && y < CFG.penTop - 40 && y > 230 && x > 170 && x < 1230;
  const tufts = [], flowers = [], bushes = [], rocks = [];
  for (let i = 0; i < 700 && tufts.length < 320; i++) { const x = rr(150, 1250), y = rr(220, CFG.penTop - 60); if (okSpot(x, y)) tufts.push({ x: X(x), y: 0.45, z: Z(y), s: rr(0.7, 1.4), r: rr(0, 6), col: hsl(rr(0.25, 0.36), 0.55, rr(0.32, 0.5)) }); }
  const fcols = [0xff5d8f, 0xffd23a, 0xffffff, 0xff8a3d, 0xc78bff];
  for (let i = 0; i < 600 && flowers.length < 160; i++) { const x = rr(150, 1250), y = rr(220, CFG.penTop - 60); if (okSpot(x, y)) flowers.push({ x: X(x), y: 0.55, z: Z(y), s: rr(0.8, 1.3), col: new THREE.Color(fcols[(rnd() * 5) | 0]) }); }
  for (let i = 0; i < 300 && bushes.length < 40; i++) { const x = rr(150, 1250), y = rr(220, CFG.penTop - 60); if (okSpot(x, y)) bushes.push({ x: X(x), y: 0.7, z: Z(y), s: rr(0.8, 1.5), sy: 0.8, col: hsl(rr(0.27, 0.35), 0.5, rr(0.28, 0.4)) }); }
  for (let i = 0; i < 300 && rocks.length < 34; i++) { const x = rr(150, 1250), y = rr(220, CFG.penTop - 60); if (okSpot(x, y)) rocks.push({ x: X(x), y: 0.5, z: Z(y), s: rr(0.6, 1.6), sy: rr(0.6, 1), r: rr(0, 6), col: hsl(0.1, 0.05, rr(0.42, 0.62)) }); }
  const shore = [];     // rochas na orla
  for (let i = 0; i < 60; i++) {
    const t = i / 60 * 4, e = Math.floor(t), f = t - e;
    const px0 = [60, 1340, 1340, 60], pz0 = [120, 120, 2940, 2940], px1 = [1340, 1340, 60, 60], pz1 = [120, 2940, 2940, 120];
    shore.push({ x: X(px0[e] + (px1[e] - px0[e]) * f), y: -0.2, z: Z(pz0[e] + (pz1[e] - pz0[e]) * f), s: rr(0.9, 1.8), r: rr(0, 6), col: hsl(0.08, 0.06, rr(0.35, 0.55)) });
  }
  g.add(instanced(new THREE.ConeGeometry(0.14, 0.7, 4), mat({ color: 0xffffff }), tufts));
  g.add(instanced(new THREE.SphereGeometry(0.16, 6, 5), mat({ color: 0xffffff, roughness: 0.6 }), flowers));
  g.add(instanced(new THREE.IcosahedronGeometry(0.9, 0), mat({ color: 0xffffff, flatShading: true }), bushes, true));
  g.add(instanced(new THREE.DodecahedronGeometry(0.8, 0), mat({ color: 0xffffff, flatShading: true }), rocks, true));
  g.add(instanced(new THREE.DodecahedronGeometry(0.9, 0), mat({ color: 0xffffff, flatShading: true }), shore, true));

  // nuvens low-poly
  refs.clouds = new THREE.Group(); g.add(refs.clouds);
  const cm = mat({ color: 0xffffff, roughness: 1, flatShading: true, transparent: true, opacity: 0.92 });
  for (let i = 0; i < 14; i++) {
    const c = new THREE.Group();
    for (let k = 0; k < 4; k++) { const b = new THREE.Mesh(new THREE.IcosahedronGeometry(rr(2.2, 3.6), 0), cm); b.position.set(k * 3 - 4.5, rr(-0.4, 0.8), rr(-1.5, 1.5)); b.scale.y = 0.65; c.add(b); }
    c.position.set(-40 + (i * 53) % 190, 40 + (i % 4) * 4, -20 + ((i * 37) % 190)); refs.clouds.add(c);
  }
  return refs;
}

// ---------- árvores variadas (pinheiro, carvalho, outono) ----------
export function buildTrees(group, trees) {
  while (group.children.length) group.remove(group.children[0]);
  seed = 4242;
  const trunks = [], c1 = [], c2 = [], c3 = [], b1 = [], b2 = [], b3 = [];
  trees.forEach((t, i) => {
    const x = X(t.x), z = Z(t.y), s = t.s * rr(0.9, 1.35), type = i % 3, r = rr(0, 6);
    trunks.push({ x, y: 1.3 * s, z, s, sy: 1, r, col: hsl(0.07, 0.4, rr(0.2, 0.3)) });
    if (type === 0) {
      const col = hsl(rr(0.33, 0.4), 0.5, rr(0.22, 0.3));
      c1.push({ x, y: 3.4 * s, z, s, r, col }); c2.push({ x, y: 5.1 * s, z, s, r, col }); c3.push({ x, y: 6.6 * s, z, s, r, col });
    } else {
      const col = type === 1 ? hsl(rr(0.27, 0.36), 0.55, rr(0.3, 0.42)) : hsl(rr(0.02, 0.12), 0.75, rr(0.42, 0.52));
      b1.push({ x, y: 4.2 * s, z, s, r, col });
      b2.push({ x: x + 1.2 * s, y: 3.7 * s, z: z + 0.5 * s, s: s * 0.75, col }); b3.push({ x: x - 1.0 * s, y: 3.9 * s, z: z - 0.7 * s, s: s * 0.7, col });
    }
  });
  const leaf = () => mat({ color: 0xffffff, flatShading: true, roughness: 0.95 });
  group.add(instanced(new THREE.CylinderGeometry(0.28, 0.42, 2.6, 6), mat({ color: 0xffffff }), trunks, true));
  group.add(instanced(new THREE.ConeGeometry(2.3, 3.2, 7), leaf(), c1, true));
  group.add(instanced(new THREE.ConeGeometry(1.8, 2.8, 7), leaf(), c2, true));
  group.add(instanced(new THREE.ConeGeometry(1.2, 2.4, 7), leaf(), c3, true));
  group.add(instanced(new THREE.IcosahedronGeometry(2.1, 0), leaf(), b1, true));
  group.add(instanced(new THREE.IcosahedronGeometry(2.1, 0), leaf(), b2, true));
  group.add(instanced(new THREE.IcosahedronGeometry(2.1, 0), leaf(), b3, true));
}
