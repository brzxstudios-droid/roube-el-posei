// ===== Roube el Posei 3D - bonecos humanoides low-poly com esqueleto =====
import * as THREE from 'three';

const M = (color, o) => new THREE.MeshStandardMaterial(Object.assign({ color, roughness: 0.85, metalness: 0 }, o || {}));
const capCache = {};
const cap = (r, l) => capCache[r + '_' + l] || (capCache[r + '_' + l] = new THREE.CapsuleGeometry(r, l, 4, 10));
const GEO = {
  head: new THREE.SphereGeometry(0.6, 18, 14),
  eye: new THREE.SphereGeometry(0.14, 10, 8),
  pupil: new THREE.SphereGeometry(0.075, 8, 6),
  brow: new THREE.BoxGeometry(0.26, 0.06, 0.07),
  smile: new THREE.TorusGeometry(0.15, 0.028, 6, 14, Math.PI),
  mouthO: new THREE.SphereGeometry(0.1, 10, 8),
  hand: new THREE.SphereGeometry(0.19, 10, 8),
  shoe: new THREE.BoxGeometry(0.42, 0.22, 0.7),
  dome: new THREE.SphereGeometry(0.66, 16, 10, 0, Math.PI * 2, 0, Math.PI / 2),
  bill: new THREE.BoxGeometry(0.9, 0.07, 0.55),
  mask: new THREE.CylinderGeometry(0.63, 0.63, 0.3, 18, 1, true, -1.15, 2.3),
  shades: new THREE.CylinderGeometry(0.62, 0.62, 0.17, 16, 1, true, -0.95, 1.9),
  hairBack: new THREE.BoxGeometry(1.1, 1.0, 0.3),
  pony: new THREE.SphereGeometry(0.24, 10, 8),
  belt: new THREE.TorusGeometry(0.5, 0.07, 6, 14),
  scarf: new THREE.TorusGeometry(0.36, 0.1, 6, 14),
  cape: new THREE.BoxGeometry(1.0, 1.5, 0.08),
  bag: new THREE.SphereGeometry(0.5, 10, 8),
  badge: new THREE.CylinderGeometry(0.12, 0.12, 0.05, 6),
  crownRing: new THREE.CylinderGeometry(0.42, 0.5, 0.26, 8, 1, true),
  crownTip: new THREE.ConeGeometry(0.1, 0.3, 4),
  halo: new THREE.TorusGeometry(0.45, 0.05, 8, 20),
  pom: new THREE.SphereGeometry(0.16, 8, 6)
};

const JOINTS = ['rootY', 'rootRX', 'hipsRX', 'spineX', 'headX', 'headY', 'aLx', 'aLz', 'eLx', 'aRx', 'aRz', 'eRx', 'tLx', 'kLx', 'tRx', 'kRx'];
const zero = () => { const o = {}; for (const k of JOINTS) o[k] = 0; return o; };

// opts: skin shirt pants shoes hair hairColor mask bag belt badge vest scarf cape shades crown halo gloves
export function makeHuman(o) {
  const skin = M(o.skin || '#f1c9a0', { roughness: 0.65 });
  const shirt = M(o.shirt || '#4a90e2');
  const pants = M(o.pants || '#2c3e66');
  const shoes = M(o.shoes || '#222222');
  const glove = o.gloves ? M(o.gloves) : skin;
  const group = new THREE.Group(), root = new THREE.Group(), body = new THREE.Group();
  body.scale.setScalar(0.72); group.add(root); root.add(body);
  const grp = (parent, x, y, z) => { const g = new THREE.Group(); g.position.set(x || 0, y || 0, z || 0); parent.add(g); return g; };
  const add = (geo, mat, parent, x, y, z, cast) => {
    const m = new THREE.Mesh(geo, mat); m.position.set(x || 0, y || 0, z || 0);
    if (cast) m.castShadow = true; parent.add(m); return m;
  };

  const hips = grp(body, 0, 1.2, 0);
  const pel = add(cap(0.42, 0.1), pants, hips, 0, 0.0, 0, true); pel.scale.set(1.15, 0.8, 0.85);
  const spine = grp(hips, 0, 0.1, 0);
  const tor = add(cap(0.46, 0.4), shirt, spine, 0, 0.5, 0, true); tor.scale.set(1.08, 1, 0.8);
  const chest = grp(spine, 0, 0.6, 0);
  const neck = grp(chest, 0, 0.55, 0);
  const hd = grp(neck, 0, 0.6, 0);

  // ----- cabeça e rosto -----
  const head = add(GEO.head, skin, hd, 0, 0, 0, true); head.scale.set(1, 1.05, 1);
  const ez = o.mask ? 0.62 : 0.52;
  const eyeMat = M('#ffffff', { roughness: 0.4 }), pupMat = M('#15151a', { roughness: 0.3 }), browMat = M(o.hairColor || '#2b1d12');
  const eyeL = add(GEO.eye, eyeMat, hd, -0.22, 0.08, ez), eyeR = add(GEO.eye, eyeMat, hd, 0.22, 0.08, ez);
  eyeL.scale.z = eyeR.scale.z = 0.55;
  const pupL = add(GEO.pupil, pupMat, hd, -0.22, 0.08, ez + 0.07), pupR = add(GEO.pupil, pupMat, hd, 0.22, 0.08, ez + 0.07);
  const browL = add(GEO.brow, browMat, hd, -0.22, 0.3, ez + 0.02), browR = add(GEO.brow, browMat, hd, 0.22, 0.3, ez + 0.02);
  const mouthMat = M('#7a2a2a', { roughness: 0.5 });
  const smile = add(GEO.smile, mouthMat, hd, 0, -0.18, 0.56);
  const mopen = add(GEO.mouthO, M('#3a0f12'), hd, 0, -0.26, 0.52); mopen.scale.set(1, 1.2, 0.4); mopen.visible = false;
  add(GEO.hand, skin, hd, 0, -0.04, 0.6).scale.set(0.32, 0.26, 0.3);            // nariz
  add(GEO.hand, skin, hd, -0.6, 0, 0).scale.set(0.2, 0.34, 0.2);                 // orelhas
  add(GEO.hand, skin, hd, 0.6, 0, 0).scale.set(0.2, 0.34, 0.2);

  // ----- cabelo / chapéu -----
  const hairMat = M(o.hairColor || '#3b2616', { roughness: 0.9 });
  const hs = o.hair || 'short';
  if (hs === 'short' || hs === 'long' || hs === 'pony') {
    const d = add(GEO.dome, hairMat, hd, 0, 0.1, -0.04, true); d.rotation.x = -0.45;
    if (hs === 'long') add(GEO.hairBack, hairMat, hd, 0, -0.18, -0.46);
    if (hs === 'pony') { add(GEO.pony, hairMat, hd, 0, 0.12, -0.72).scale.set(1, 1.3, 1); }
  } else if (hs === 'cap' || hs === 'beanie') {
    const hm = M(o.hatColor || '#111111');
    const d = add(GEO.dome, hm, hd, 0, 0.14, -0.02, true); d.rotation.x = hs === 'cap' ? -0.25 : -0.12; d.scale.setScalar(1.04);
    if (hs === 'cap') { const b = add(GEO.bill, hm, hd, 0, 0.2, 0.66); b.rotation.x = 0.18; }
    else add(GEO.pom, hm, hd, 0, 0.82, -0.06);
  }
  if (o.mask) { const mk = add(GEO.mask, M('#0d0d10', { side: THREE.DoubleSide }), hd, 0, 0.1, 0); mk.castShadow = false; }
  if (o.shades) add(GEO.shades, M('#050508', { roughness: 0.2, side: THREE.DoubleSide }), hd, 0, 0.1, 0);

  // ----- braços -----
  const mkArm = sx => {
    const sh = grp(chest, sx * 0.68, 0.25, 0);
    add(cap(0.19, 0.28), shirt, sh, 0, -0.33, 0);
    const el = grp(sh, 0, -0.62, 0);
    add(cap(0.17, 0.26), o.longSleeve ? shirt : skin, el, 0, -0.3, 0);
    add(GEO.hand, glove, el, 0, -0.66, 0);
    return { sh, el };
  };
  const L = mkArm(-1), R = mkArm(1);
  // ----- pernas -----
  const mkLeg = sx => {
    const th = grp(hips, sx * 0.3, -0.05, 0);
    add(cap(0.24, 0.12), pants, th, 0, -0.3, 0, true);
    const kn = grp(th, 0, -0.58, 0);
    add(cap(0.2, 0.14), pants, kn, 0, -0.28, 0, true);
    add(GEO.shoe, shoes, kn, 0, -0.5, 0.1);
    return { th, kn };
  };
  const lL = mkLeg(-1), lR = mkLeg(1);

  // ----- acessórios -----
  const extras = {};
  if (o.belt) { const b = add(GEO.belt, M(o.belt, { roughness: 0.5 }), spine, 0, 0.12, 0); b.rotation.x = Math.PI / 2; b.scale.set(1.1, 0.8, 1); }
  if (o.badge) { const b = add(GEO.badge, M('#ffd23a', { metalness: 0.6, roughness: 0.3 }), chest, -0.26, 0.0, 0.38); b.rotation.x = Math.PI / 2; }
  if (o.bag) {
    const bag = add(GEO.bag, M('#7a4b22'), chest, 0, -0.1, -0.55, true); bag.scale.set(1, 1.1, 0.8);
    add(GEO.pom, M('#5a3516'), chest, 0, 0.5, -0.5);
    add(GEO.pom, M('#ffc400', { emissive: '#664a00', metalness: 0.6 }), chest, 0.25, 0.2, -0.88).scale.set(1, 1, 0.4);
    extras.bag = bag;
  }
  if (o.scarf) { const s = add(GEO.scarf, M(o.scarf), neck, 0, 0.0, 0); s.rotation.x = Math.PI / 2; }
  if (o.cape) { const cg = grp(chest, 0, 0.45, -0.4); add(GEO.cape, M(o.cape, { side: THREE.DoubleSide }), cg, 0, -0.7, 0); extras.cape = cg; }
  if (o.crown) {
    const gold = M('#ffd23a', { metalness: 0.7, roughness: 0.3, emissive: '#6b5200' });
    const cg = grp(hd, 0, 0.72, 0); add(GEO.crownRing, gold, cg, 0, 0, 0);
    for (let i = 0; i < 6; i++) { const a = i / 6 * Math.PI * 2; add(GEO.crownTip, gold, cg, Math.sin(a) * 0.46, 0.25, Math.cos(a) * 0.46); }
  }
  if (o.halo) {
    const h = add(GEO.halo, new THREE.MeshBasicMaterial({ color: 0xfff1a8 }), hd, 0, 1.05, 0); h.rotation.x = Math.PI / 2; extras.halo = h;
  }

  return {
    group, root, hips, spine, chest, neck, hd, aL: L.sh, eL: L.el, aR: R.sh, eR: R.el, tL: lL.th, kL: lL.kn, tR: lR.th, kR: lR.kn,
    mats: { shirt, pants, skin }, face: { browL, browR, eyeL, eyeR, pupL, pupR, smile, mopen },
    extras, cur: zero(), ph: Math.random() * 6, expr: 'neutral', ecur: { b: 0, by: 0, es: 1, ms: 1 }
  };
}

// ===== Expressões faciais =====
// b>0 sobrancelha "triste/assustada" (ponta de dentro sobe); b<0 brava. m: s sorriso, f carranca, o boca aberta, l linha
const EXPR = {
  neutral: { b: 0.0, by: 0, es: 1.0, m: 'l', ms: 1 },
  happy:   { b: 0.12, by: 0.03, es: 0.85, m: 's', ms: 1.25 },
  grin:    { b: -0.25, by: 0, es: 0.9, m: 's', ms: 1.5 },
  scared:  { b: 0.5, by: 0.1, es: 1.3, m: 'o', ms: 1.1 },
  angry:   { b: -0.55, by: -0.02, es: 0.95, m: 'f', ms: 1.1 },
  strain:  { b: -0.2, by: 0, es: 0.65, m: 'f', ms: 0.8 },
  dizzy:   { b: 0.3, by: 0.05, es: 1.1, m: 'o', ms: 0.8 },
  sly:     { b: -0.35, by: 0, es: 0.8, m: 's', ms: 0.8 }
};

function gait(P, ph, run, amt) {
  const s = Math.sin(ph), c = Math.cos(ph);
  const A = (0.62 + run * 0.45) * amt, B = (0.9 + run * 0.8) * amt;
  P.tLx = -s * A; P.tRx = s * A;
  P.kLx = Math.max(0, c) * B + run * 0.2 * amt; P.kRx = Math.max(0, -c) * B + run * 0.2 * amt;
  P.rootY = (Math.abs(c) * (0.06 + run * 0.08) - 0.03) * amt;
  return s;
}

// pilotando: patinete (em pé) ou moto (sentado), mãos no guidão
function ride(P, veh, t, sp) {
  if (veh === 'moto') {
    P.rootY = 0.3; P.tLx = P.tRx = -1.3; P.kLx = P.kRx = 1.25; P.spineX = 0.22; P.headX = -0.2;
    P.aLx = P.aRx = -1.15; P.eLx = P.eRx = -0.35; P.aLz = -0.1; P.aRz = 0.1;
  } else {
    P.rootY = 0.42 + Math.sin(t * 14) * 0.012 * sp; P.tLx = -0.2; P.kLx = 0.25; P.tRx = 0.35; P.kRx = 0.4; P.spineX = 0.12; P.headX = -0.1;
    P.aLx = P.aRx = -1.2; P.eLx = P.eRx = -0.3; P.aLz = -0.1; P.aRz = 0.1;
  }
}

// Gera a pose-alvo para um estado. a: { t, speed(0..1.4), run(0/1), u(0..1 progresso do roubo), look, h, vh, seed }
export function poseFor(st, rig, a) {
  const P = zero(), t = a.t || 0, ph = rig.ph, sp = Math.min(1.2, a.speed || 0);
  const run = a.run ? 1 : 0;
  let expr = 'neutral';
  switch (st) {
    case 'walk': {
      const s = gait(P, ph, 0, Math.min(1, sp + 0.2));
      P.aLx = s * 0.6; P.aRx = -s * 0.6; P.eLx = P.eRx = -0.3; P.spineX = 0.05;
      P.aLz = -0.06; P.aRz = 0.06; P.headY = a.look || 0; break;
    }
    case 'run': {
      const s = gait(P, ph, 1, 1);
      P.aLx = s * 1.1; P.aRx = -s * 1.1; P.eLx = P.eRx = -1.4; P.spineX = 0.3; P.hipsRX = 0.06; P.headX = -0.22;
      P.aLz = -0.1; P.aRz = 0.1; expr = 'grin'; break;
    }
    case 'carry': { // gait + braços para cima segurando o Posei
      gait(P, ph, run, Math.min(1, sp + 0.25));
      if (a.veh) ride(P, a.veh, t, sp);
      P.aLx = -3.0; P.aRx = -3.0; P.aLz = -0.18; P.aRz = 0.18; P.eLx = P.eRx = -0.15;
      P.spineX = -0.12 + run * 0.12; P.headX = -0.3; expr = 'strain'; break;
    }
    case 'jump': {
      const up = (a.vh || 0) > 0;
      if (up) { P.aLx = P.aRx = -2.6; P.aLz = -0.25; P.aRz = 0.25; P.tLx = -0.8; P.kLx = 1.3; P.tRx = -0.15; P.kRx = 0.6; P.spineX = 0.1; }
      else { P.aLz = -1.3; P.aRz = 1.3; P.aLx = P.aRx = -0.3; P.tLx = -0.4; P.kLx = 0.7; P.tRx = 0.25; P.kRx = 0.5; P.spineX = 0.05; }
      expr = 'happy'; break;
    }
    case 'grab': { // alcança, agacha e agarra (u: 0..1)
      const u = Math.min(1, a.u || 0), reach = Math.min(1, u / 0.6), sq = u < 0.6 ? 0 : (u - 0.6) / 0.4;
      P.rootY = -0.42 * reach; P.tLx = P.tRx = -1.05 * reach; P.kLx = P.kRx = 1.8 * reach;
      P.spineX = 0.62 * reach + 0.28 * sq; P.headX = -0.45 * reach;
      P.aLx = P.aRx = -1.55 * reach - 0.2 * sq; P.eLx = P.eRx = -0.2 - 0.95 * sq;
      P.aLz = -0.1 + 0.65 * sq; P.aRz = 0.1 - 0.65 * sq; expr = 'sly'; break;
    }
    case 'ride': {
      ride(P, a.veh, t, sp); P.headY = a.look || 0; expr = sp > 0.3 ? 'grin' : 'neutral'; break;
    }
    case 'cheer': {
      const b = Math.abs(Math.sin(t * 9));
      P.aLz = -2.7; P.aRz = 2.7; P.eLx = P.eRx = -0.4; P.rootY = b * 0.3; P.kLx = P.kRx = b * 0.5; P.tLx = P.tRx = -b * 0.25;
      P.spineX = -0.1; P.headX = -0.2; expr = 'happy'; break;
    }
    case 'down': { // levou um tombo
      P.rootRX = -1.4; P.rootY = 0.05; P.aLx = -0.5; P.aRx = -0.2; P.aLz = -1.0; P.aRz = 1.0; P.tLx = -0.3; P.tRx = 0.2; P.kLx = 0.3; P.kRx = 0.1;
      P.headX = 0.3; expr = 'dizzy'; break;
    }
    case 'scared': {
      const tr = Math.sin(t * 28) * 0.08;
      P.aLx = P.aRx = -1.9; P.eLx = -1.9 + tr; P.eRx = -1.9 - tr; P.spineX = -0.25; P.headX = 0.2;
      P.tLx = -0.25; P.kLx = 0.5; P.tRx = 0.1; P.rootY = Math.abs(Math.sin(t * 18)) * 0.06; expr = 'scared'; break;
    }
    case 'struggle': { // sendo carregado (rootRX deita o corpo)
      const w = Math.sin(t * 15), w2 = Math.sin(t * 15 + 2);
      P.rootRX = 1.35; P.aLx = -2.7 + w * 0.6; P.aRx = -2.7 + w2 * 0.6; P.aLz = -0.6 + w2 * 0.3; P.aRz = 0.6 + w * 0.3;
      P.tLx = w * 0.9; P.tRx = -w * 0.9; P.kLx = P.kRx = 0.6; P.spineX = -0.1; expr = 'scared'; break;
    }
    case 'wave': {
      P.aRz = 2.5; P.eRx = -0.5 + Math.sin(t * 9) * 0.7; P.aLz = -0.08; P.eLx = -0.15; P.spineX = Math.sin(t * 2) * 0.02;
      P.headY = a.look || 0; expr = 'happy'; break;
    }
    case 'dance': {
      const o = a.seed || 0, w = Math.sin(t * 6 + o), b = Math.abs(w);
      P.aLz = -1.6 - 0.8 * w; P.aRz = 1.6 + 0.8 * Math.sin(t * 6 + o + 1.5); P.eLx = P.eRx = -0.3; P.rootY = b * 0.15;
      P.tLx = -b * 0.2; P.kLx = b * 0.4; P.tRx = b * 0.15; P.kRx = b * 0.3; P.headY = Math.sin(t * 3 + o) * 0.3; expr = 'happy'; break;
    }
    default: { // idle
      P.spineX = Math.sin(t * 2 + (a.seed || 0)) * 0.025; P.aLz = -0.08; P.aRz = 0.08; P.eLx = P.eRx = -0.15;
      P.headY = a.look || 0; P.headX = Math.sin(t * 1.3) * 0.03; expr = a.expr || 'neutral';
    }
  }
  return { P, expr };
}

// Aplica a pose com suavização (transições fluidas entre estados)
export function animate(rig, st, dt, a) {
  a = a || {};
  const sp = a.speed || 0, run = a.run ? 1 : 0;
  rig.ph += dt * (sp > 0.05 ? 3.5 + sp * 6 + run * 3 : 0);
  const r = poseFor(st, rig, a), P = r.P, cur = rig.cur;
  const k = Math.min(1, dt * (st === 'down' ? 22 : 14));
  for (const j of JOINTS) cur[j] += (P[j] - cur[j]) * k;
  rig.root.position.y = cur.rootY; rig.root.rotation.x = cur.rootRX;
  rig.hips.rotation.x = cur.hipsRX; rig.spine.rotation.x = cur.spineX;
  rig.neck.rotation.x = cur.headX; rig.neck.rotation.y = cur.headY;
  rig.aL.rotation.set(cur.aLx, 0, cur.aLz); rig.aR.rotation.set(cur.aRx, 0, cur.aRz);
  rig.eL.rotation.x = cur.eLx; rig.eR.rotation.x = cur.eRx;
  rig.tL.rotation.x = cur.tLx; rig.tR.rotation.x = cur.tRx; rig.kL.rotation.x = cur.kLx; rig.kR.rotation.x = cur.kRx;
  setExpression(rig, a.expr && st !== 'down' && st !== 'scared' ? a.expr : r.expr, dt);
  const ex = rig.extras;
  if (ex.cape) ex.cape.rotation.x = 0.12 + sp * 0.5 + Math.sin((a.t || 0) * 6) * 0.05;
  if (ex.halo) { ex.halo.position.y = 1.05 + Math.sin((a.t || 0) * 3) * 0.06; ex.halo.rotation.z = (a.t || 0) * 1.5; }
  return cur;
}

export function setExpression(rig, name, dt) {
  const E = EXPR[name] || EXPR.neutral, f = rig.face, c = rig.ecur, k = Math.min(1, (dt || 0.016) * 12);
  c.b += (E.b - c.b) * k; c.by += (E.by - c.by) * k; c.es += (E.es - c.es) * k; c.ms += (E.ms - c.ms) * k;
  f.browL.rotation.z = c.b; f.browR.rotation.z = -c.b;
  f.browL.position.y = f.browR.position.y = 0.3 + c.by;
  f.eyeL.scale.y = f.eyeR.scale.y = c.es; f.eyeL.scale.x = f.eyeR.scale.x = 1 + (c.es - 1) * 0.5;
  f.pupL.scale.setScalar(1 + (c.es - 1) * 0.6); f.pupR.scale.setScalar(1 + (c.es - 1) * 0.6);
  const open = E.m === 'o';
  f.mopen.visible = open; f.smile.visible = !open;
  if (open) f.mopen.scale.set(c.ms, 1.2 * c.ms, 0.4);
  else {
    f.smile.rotation.z = E.m === 's' ? Math.PI : 0;
    f.smile.position.y = E.m === 's' ? -0.1 : -0.28;
    f.smile.scale.set(c.ms, E.m === 'l' ? 0.12 : c.ms, 1);
  }
  rig.expr = name;
}

// ===== utilitários visuais =====
let glowTex = null;
export function glowTexture() {
  if (glowTex) return glowTex;
  const c = document.createElement('canvas'); c.width = c.height = 64;
  const g = c.getContext('2d'), gr = g.createRadialGradient(32, 32, 0, 32, 32, 32);
  gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(0.35, 'rgba(255,255,255,0.45)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
  g.fillStyle = gr; g.fillRect(0, 0, 64, 64);
  glowTex = new THREE.CanvasTexture(c); glowTex.colorSpace = THREE.SRGBColorSpace; return glowTex;
}
export function glowSprite(color, size, opacity) {
  const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTexture(), color, transparent: true, opacity: opacity || 0.8, depthWrite: false, blending: THREE.AdditiveBlending }));
  s.scale.set(size, size, 1); return s;
}

// estrelinhas girando (tonto/atordoado)
export function makeStars() {
  const g = new THREE.Group(), m = new THREE.MeshBasicMaterial({ color: 0xffe066 });
  for (let i = 0; i < 3; i++) { const s = new THREE.Mesh(new THREE.OctahedronGeometry(0.22), m); g.add(s); }
  g.visible = false; return g;
}
export function spinStars(g, t) {
  g.children.forEach((s, i) => { const a = t * 5 + i * 2.09; s.position.set(Math.sin(a) * 0.9, 0, Math.cos(a) * 0.9); s.rotation.y = t * 6; });
}

export function makeLabel(text, color, stars) {
  const c = document.createElement('canvas'); c.width = 256; c.height = 72;
  const g = c.getContext('2d');
  g.fillStyle = 'rgba(10,12,24,0.72)';
  g.beginPath(); if (g.roundRect) g.roundRect(4, 6, 248, 60, 18); else g.rect(4, 6, 248, 60); g.fill();
  g.strokeStyle = color; g.lineWidth = 3; g.stroke();
  g.fillStyle = '#ffffff'; g.font = 'bold 26px sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle';
  g.fillText(text, 128, 26);
  const ns = stars === undefined ? 1 : stars;
  if (ns > 0) { g.fillStyle = color; g.font = '20px sans-serif'; g.fillText('★'.repeat(ns), 128, 50); }
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
  const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: t, transparent: true, depthTest: false }));
  s.scale.set(5, 1.4, 1); s.renderOrder = 10; return s;
}
export function makeBang() {
  const c = document.createElement('canvas'); c.width = c.height = 64;
  const g = c.getContext('2d');
  g.fillStyle = '#e23b3b'; g.beginPath(); g.arc(32, 32, 28, 0, 6.28); g.fill();
  g.strokeStyle = '#fff'; g.lineWidth = 3; g.stroke();
  g.fillStyle = '#fff'; g.font = 'bold 44px sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('!', 32, 35);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
  const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: t, transparent: true, depthTest: false }));
  s.scale.set(1.5, 1.5, 1); s.renderOrder = 11; return s;
}
export function textPlane(text, w, h, bg, fg, font) {
  const c = document.createElement('canvas'); c.width = 512; c.height = Math.round(512 * h / w);
  const g = c.getContext('2d');
  g.fillStyle = bg; g.fillRect(0, 0, c.width, c.height);
  g.fillStyle = fg; g.font = font || 'bold 64px sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle';
  g.fillText(text, c.width / 2, c.height / 2 + 4);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
  return new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshBasicMaterial({ map: t }));
}
export function checkerTexture(cols, rows) {
  const c = document.createElement('canvas'); c.width = cols * 32; c.height = rows * 32;
  const g = c.getContext('2d');
  for (let i = 0; i < cols; i++) for (let j = 0; j < rows; j++) { g.fillStyle = (i + j) % 2 ? '#15151a' : '#ffffff'; g.fillRect(i * 32, j * 32, 32, 32); }
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
}

// teste de sanidade das poses (usado nos testes automáticos)
export function selfTest(rig) {
  const states = ['idle', 'walk', 'run', 'carry', 'jump', 'grab', 'cheer', 'down', 'scared', 'struggle', 'wave', 'dance', 'ride'];
  const bad = [];
  for (const s of states) {
    for (let i = 0; i < 20; i++) {
      const cur = animate(rig, s, 0.016, { t: i * 0.1, speed: 1, run: i % 2, u: i / 19, vh: i % 3 - 1, veh: i % 2 ? 'moto' : 'scooter' });
      for (const j of JOINTS) if (!Number.isFinite(cur[j])) bad.push(s + ':' + j);
    }
  }
  return bad;
}


// ===== veículos =====
const whCache = {};
function wheelGeo(r, w) {
  const k = r + '_' + w;
  if (!whCache[k]) { const g = new THREE.CylinderGeometry(r, r, w, 14); g.rotateZ(Math.PI / 2); whCache[k] = g; }
  return whCache[k];
}
function mkWheel(r, w, parent, x, y, z) {
  const g = new THREE.Group(); g.position.set(x, y, z);
  const tire = new THREE.Mesh(wheelGeo(r, w), M('#16161a', { roughness: 0.9 })); tire.castShadow = true; g.add(tire);
  g.add(new THREE.Mesh(wheelGeo(r * 0.55, w * 1.1), M('#c8ccd6', { metalness: 0.6, roughness: 0.3 })));
  g.add(new THREE.Mesh(new THREE.BoxGeometry(w * 1.2, r * 1.5, 0.07), M('#3a3d48')));   // raio: dá pra ver girar
  parent.add(g); return g;
}
function vAdd(g, geo, mat, x, y, z, cast) { const o = new THREE.Mesh(geo, mat); o.position.set(x, y, z); if (cast) o.castShadow = true; g.add(o); return o; }

// origem no chão, frente = +z. wheels[] gira em rotation.x
export function makeScooter(color) {
  const g = new THREE.Group(), body = M(color || '#19b5a5', { roughness: 0.45, metalness: 0.25 }), dark = M('#2a2d36', { roughness: 0.6 });
  vAdd(g, new THREE.BoxGeometry(0.75, 0.1, 1.7), body, 0, 0.38, 0, true);
  vAdd(g, new THREE.BoxGeometry(0.6, 0.02, 1.4), M('#15161b'), 0, 0.44, -0.05);
  const rear = mkWheel(0.3, 0.14, g, 0, 0.3, -0.85), front = mkWheel(0.3, 0.14, g, 0, 0.3, 0.95);
  vAdd(g, new THREE.BoxGeometry(0.55, 0.05, 0.5), body, 0, 0.64, -0.85);
  vAdd(g, new THREE.BoxGeometry(0.1, 1.3, 0.1), dark, 0, 1.0, 0.92, true).rotation.x = -0.12;
  const bar = vAdd(g, new THREE.CylinderGeometry(0.05, 0.05, 1.0, 8), dark, 0, 1.62, 0.86); bar.rotation.z = Math.PI / 2;
  vAdd(g, new THREE.SphereGeometry(0.1, 8, 6), M('#fff6b0', { emissive: '#ffe066' }), 0, 1.42, 1.0);
  return { group: g, wheels: [rear, front], r: 0.3 };
}
export function makeMoto(color) {
  const g = new THREE.Group(), body = M(color || '#d62d2d', { roughness: 0.35, metalness: 0.35 }), dark = M('#23252d', { roughness: 0.6 });
  const rear = mkWheel(0.55, 0.3, g, 0, 0.55, -1.0), front = mkWheel(0.55, 0.26, g, 0, 0.55, 1.1);
  vAdd(g, new THREE.BoxGeometry(0.55, 0.5, 1.7), dark, 0, 0.85, -0.05, true);
  vAdd(g, new THREE.SphereGeometry(0.4, 10, 8), body, 0, 1.22, 0.3, true).scale.set(1, 0.7, 1.5);
  vAdd(g, new THREE.BoxGeometry(0.5, 0.18, 1.0), M('#101014'), 0, 1.15, -0.55);
  for (const sx of [-1, 1]) { vAdd(g, new THREE.BoxGeometry(0.08, 1.1, 0.08), M('#aeb4c2', { metalness: 0.7, roughness: 0.3 }), sx * 0.2, 0.98, 1.0, true).rotation.x = 0.3; }
  const bar = vAdd(g, new THREE.CylinderGeometry(0.05, 0.05, 1.0, 8), dark, 0, 1.5, 0.8); bar.rotation.z = Math.PI / 2;
  vAdd(g, new THREE.SphereGeometry(0.18, 8, 6), M('#fff6b0', { emissive: '#ffe066' }), 0, 1.3, 1.22);
  const ex = vAdd(g, new THREE.CylinderGeometry(0.09, 0.11, 1.0, 8), M('#8b909c', { metalness: 0.8, roughness: 0.3 }), 0.32, 0.62, -0.7); ex.rotation.x = Math.PI / 2;
  vAdd(g, new THREE.BoxGeometry(0.62, 0.05, 0.7), body, 0, 1.05, -1.3);
  return { group: g, wheels: [rear, front], r: 0.55 };
}
