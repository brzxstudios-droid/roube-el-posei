// ===== Roube el Posei 3D - renderizador (three.js) =====
import * as THREE from 'three';
import { makeHuman, animate, makeLabel, makeBang, makeStars, spinStars, glowSprite, selfTest } from './models.js';
import { X, Z, buildStatic, buildTrees } from './scene3d.js';

let renderer, scene, camera, refs, hemi, sun, sunGlow, moonGlow, stars, QUALITY = 2;
let playerM, grabRing, arrow, pStars;
const peopleMap = new Map(), guardMap = new Map(), pickMap = new Map();
let peopleGroup, guardGroup, pickGroup, mudGroup, treeGroup;
let mudRef = null, treesBuilt = false, playerAng = 0, lastT = 0, sparkT = 0, baseFov = 62;
const penPool = [];
const camPos = new THREE.Vector3();
const C = n => new THREE.Color(n);
const dayCol = C(0x8fd3ff), duskCol = C(0xff9a62), nightCol = C(0x0b1030), tmpCol = C(0xffffff);
const sunDay = C(0xfff1d0), sunDusk = C(0xff8a3d);
let floatBox = null; const floatPool = [];
const vtmp = new THREE.Vector3();

// ---------- utilidades ----------
function angLerp(a, b, k) {
  let d = b - a;
  while (d > Math.PI) d -= 2 * Math.PI;
  while (d < -Math.PI) d += 2 * Math.PI;
  return a + d * k;
}
const hex = c => String(c).slice(0, 7);
const clamp01 = v => Math.max(0, Math.min(1, v));
const easeOutBack = t => { const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2); };

export function getQuality() {
  let q = -1;
  try { const s = localStorage.getItem('rep-quality'); if (s !== null) q = parseInt(s, 10); } catch (e) {}
  if (!(q >= 0 && q <= 2)) q = (navigator.hardwareConcurrency || 4) <= 4 ? 1 : 2;
  return q;
}
const QNAMES = ['Baixa', 'Média', 'Alta'];

// ---------- fábricas ----------
const SKINS = ['#f6d3b0', '#e8b98f', '#c98f62', '#9a6a45', '#6e4a30'];
const HAIRS = ['#2b1d12', '#5a3a1f', '#a5651f', '#d8b560', '#1a1a1a', '#8a2d1c'];
const PANTS = ['#2c3e66', '#3a3a44', '#5b4630', '#274b3a', '#6a2f4a'];

function createPerson(per) {
  const id = per.id * 7 + per.hue, rc = RARITIES[per.rar];
  const m = makeHuman({
    skin: SKINS[id % 5], hairColor: HAIRS[(id >> 1) % 6], hair: ['short', 'long', 'pony', 'short', 'beanie'][id % 5],
    hatColor: 'hsl(' + ((per.hue + 120) % 360) + ',55%,45%)',
    shirt: 'hsl(' + per.hue + ',65%,55%)', pants: PANTS[(id >> 2) % 5],
    scarf: per.rar >= 1 ? rc.c : null, shades: per.rar >= 2,
    cape: per.rar >= 2 ? (per.rar === 4 ? '#ff5d8f' : per.rar === 3 ? '#d4a21a' : '#7a3fd0') : null,
    crown: per.rar >= 3, halo: per.rar >= 4
  });
  m.rar = per.rar; m.carryT = 0; m.liftFrom = new THREE.Vector3();
  m.label = makeLabel(per.name + ' · ' + rc.n, rc.c, per.rar + 1); m.label.position.y = 3.9; m.group.add(m.label);
  // aura de raridade no chão
  m.ring = new THREE.Mesh(new THREE.RingGeometry(1.2, 1.7, 28), new THREE.MeshBasicMaterial({ color: rc.c, transparent: true, opacity: 0.75, side: THREE.DoubleSide }));
  m.ring.rotation.x = -Math.PI / 2; m.ring.position.y = 0.05; m.ring.visible = per.rar > 0; m.group.add(m.ring);
  if (per.rar >= 2) { // feixe de luz: dá pra achar os valiosos de longe
    const bm = new THREE.MeshBasicMaterial({ color: rc.c, transparent: true, opacity: 0.2 + per.rar * 0.03, side: THREE.DoubleSide, depthWrite: false, blending: THREE.AdditiveBlending });
    m.beam = new THREE.Mesh(new THREE.CylinderGeometry(0.5 + per.rar * 0.12, 0.9 + per.rar * 0.15, 16, 10, 1, true), bm);
    m.beam.position.y = 8; m.group.add(m.beam);
  }
  m.hint = new THREE.Mesh(new THREE.ConeGeometry(0.4, 0.8, 4), new THREE.MeshBasicMaterial({ color: 0xffe066 }));
  m.hint.rotation.x = Math.PI; m.hint.position.y = 4.8; m.hint.visible = false; m.group.add(m.hint);
  m.group.rotation.y = (per.id % 2 ? 0.5 : -0.5);
  return m;
}
function createGuard(g) {
  const id = ((g.home.id * 3 + (g.ang * 10 | 0)) | 0) & 7;
  const m = makeHuman({ shirt: '#2f55d6', pants: '#1a2547', shoes: '#101010', hair: 'cap', hatColor: '#14213d', badge: true, belt: '#d4a21a', hairColor: HAIRS[id % 6], skin: SKINS[id % 5] });
  m.bang = makeBang(); m.bang.position.y = 3.9; m.bang.visible = false; m.group.add(m.bang);
  m.stars = makeStars(); m.stars.position.y = 3.2; m.group.add(m.stars);
  return m;
}
let coinMat = null;
function coinMaterials() {
  if (coinMat) return coinMat;
  const c = document.createElement('canvas'); c.width = c.height = 128;
  const g = c.getContext('2d'), gr = g.createRadialGradient(64, 64, 8, 64, 64, 64);
  gr.addColorStop(0, '#fff2a8'); gr.addColorStop(0.7, '#ffc400'); gr.addColorStop(1, '#c98a00');
  g.fillStyle = gr; g.fillRect(0, 0, 128, 128);
  g.strokeStyle = '#a56d00'; g.lineWidth = 8; g.beginPath(); g.arc(64, 64, 52, 0, 6.28); g.stroke();
  g.fillStyle = '#a56d00'; g.font = 'bold 64px sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('$', 64, 68);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
  const side = new THREE.MeshStandardMaterial({ color: 0xffc400, metalness: 0.7, roughness: 0.3, emissive: 0x6b4a00 });
  const face = new THREE.MeshStandardMaterial({ map: t, metalness: 0.5, roughness: 0.35, emissive: 0x4a3300 });
  coinMat = [side, face, face]; return coinMat;
}
function createPickup(it) {
  const grp = new THREE.Group();
  let mesh, glow;
  if (it.kind === 'boost') {
    const s = new THREE.Shape(); [[0.1, 1], [-0.55, -0.05], [-0.1, -0.05], [-0.25, -1], [0.55, 0.2], [0.1, 0.2], [0.4, 1]].forEach((p, i) => i ? s.lineTo(p[0], p[1]) : s.moveTo(p[0], p[1]));
    const geo = new THREE.ExtrudeGeometry(s, { depth: 0.3, bevelEnabled: false }); geo.translate(0, 0, -0.15);
    mesh = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({ color: 0xffe066, emissive: 0xb38600, roughness: 0.4 })); glow = 0xffe066;
  } else if (it.kind === 'shield') {
    mesh = new THREE.Group();
    mesh.add(new THREE.Mesh(new THREE.SphereGeometry(0.8, 14, 10), new THREE.MeshStandardMaterial({ color: 0x4aa8ff, emissive: 0x0e3a66, roughness: 0.3, transparent: true, opacity: 0.85 })));
    const rg = new THREE.Mesh(new THREE.TorusGeometry(1.0, 0.07, 6, 20), new THREE.MeshBasicMaterial({ color: 0xbfe8ff })); mesh.add(rg); glow = 0x7ad7ff;
  } else {
    const geo = new THREE.CylinderGeometry(0.85, 0.85, 0.22, 20); geo.rotateX(Math.PI / 2);
    mesh = new THREE.Mesh(geo, coinMaterials()); glow = 0xffd23a;
  }
  mesh.castShadow = true; grp.add(mesh); grp.userData.mesh = mesh;
  grp.add(glowSprite(glow, 3.6, 0.75));
  return { group: grp };
}

// ---------- efeitos (partículas) ----------
const sparkPool = [], coinPool = [], spritePool = [], ringPool = [];
function initFX() {
  const sg = new THREE.OctahedronGeometry(0.17);
  for (let i = 0; i < 90; i++) { const m = new THREE.Mesh(sg, new THREE.MeshBasicMaterial({ color: 0xffffff })); m.visible = false; scene.add(m); sparkPool.push(m); }
  const cg = new THREE.CylinderGeometry(0.3, 0.3, 0.08, 12); cg.rotateX(Math.PI / 2);
  const cm = new THREE.MeshStandardMaterial({ color: 0xffc400, metalness: 0.7, roughness: 0.3, emissive: 0x6b4a00 });
  for (let i = 0; i < 60; i++) { const m = new THREE.Mesh(cg, cm); m.visible = false; scene.add(m); coinPool.push(m); }
  for (let i = 0; i < 140; i++) { const s = glowSprite(0xffffff, 1, 0.8); s.visible = false; scene.add(s); spritePool.push(s); }
  const rg = new THREE.RingGeometry(0.9, 1.0, 32);
  for (let i = 0; i < 6; i++) {
    const m = new THREE.Mesh(rg, new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.8, side: THREE.DoubleSide, blending: THREE.AdditiveBlending, depthWrite: false }));
    m.rotation.x = -Math.PI / 2; m.visible = false; scene.add(m); ringPool.push(m);
  }
}
function drawFX(t) {
  let a = 0, b = 0, s = 0, r = 0;
  for (const q of G.parts) {
    const k = clamp01(q.life / (q.max || 1));
    if (q.kind === 'coin') {
      if (b >= coinPool.length) continue; const m = coinPool[b++];
      m.visible = true; m.position.set(X(q.x), q.h, Z(q.y)); m.rotation.y = t * 10 + q.spin; m.scale.setScalar(0.6 + k * 0.6);
    } else if (q.kind === 'dust' || q.kind === 'sparkle') {
      if (s >= spritePool.length) continue; const m = spritePool[s++];
      m.visible = true; m.position.set(X(q.x), q.h, Z(q.y));
      const dust = q.kind === 'dust';
      m.scale.set(dust ? 1.6 - k * 0.8 : 0.5 + k * 0.5, dust ? 1.6 - k * 0.8 : 0.5 + k * 0.5, 1);
      m.material.color.set(hex(q.c)); m.material.opacity = (dust ? 0.5 : 0.9) * k;
      m.material.blending = dust ? THREE.NormalBlending : THREE.AdditiveBlending;
    } else if (q.kind === 'ring') {
      if (r >= ringPool.length) continue; const m = ringPool[r++];
      m.visible = true; m.position.set(X(q.x), 0.45, Z(q.y)); m.scale.setScalar(1 + (1 - k) * 8); m.material.opacity = 0.85 * k; m.material.color.set(hex(q.c));
    } else {
      if (a >= sparkPool.length) continue; const m = sparkPool[a++];
      m.visible = true; m.position.set(X(q.x), q.h, Z(q.y)); m.material.color.set(hex(q.c)); m.scale.setScalar(0.5 + k); m.rotation.y = t * 8;
    }
  }
  for (let i = a; i < sparkPool.length; i++) sparkPool[i].visible = false;
  for (let i = b; i < coinPool.length; i++) coinPool[i].visible = false;
  for (let i = s; i < spritePool.length; i++) spritePool[i].visible = false;
  for (let i = r; i < ringPool.length; i++) ringPool[i].visible = false;
}

// ---------- inicialização ----------
function init() {
  QUALITY = getQuality();
  const canvas = document.getElementById('game');
  renderer = new THREE.WebGLRenderer({ canvas, antialias: QUALITY > 0, powerPreference: 'high-performance' });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, [1, 1.25, 1.75][QUALITY]));
  renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.05;
  if (QUALITY > 0) { renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap; }
  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x8fd3ff);
  scene.fog = new THREE.Fog(0x8fd3ff, 60, 160);
  camera = new THREE.PerspectiveCamera(62, 1, 0.5, 400);
  hemi = new THREE.HemisphereLight(0xcfe9ff, 0x6a8a4a, 1.1); scene.add(hemi);
  sun = new THREE.DirectionalLight(0xfff1d0, 2.4); scene.add(sun, sun.target);
  if (QUALITY > 0) {
    sun.castShadow = true;
    const ms = QUALITY === 2 ? 1536 : 768; sun.shadow.mapSize.set(ms, ms);
    const sc = sun.shadow.camera; sc.left = -26; sc.right = 26; sc.top = 26; sc.bottom = -26; sc.near = 1; sc.far = 160;
    sun.shadow.bias = -0.0008; sun.shadow.normalBias = 0.04; sun.shadow.radius = 3;
  }
  refs = buildStatic(scene);
  // sol, lua e estrelas (seguem a câmera)
  sunGlow = glowSprite(0xffe9a0, 46, 0.95); sunGlow.material.fog = false; scene.add(sunGlow);
  moonGlow = glowSprite(0xcfe0ff, 26, 0.0); moonGlow.material.fog = false; scene.add(moonGlow);
  const sp = [];
  for (let i = 0; i < 260; i++) { const u = Math.random() * 2 - 1, a = Math.random() * 6.28, r = Math.sqrt(1 - u * u); sp.push(Math.cos(a) * r * 190, Math.abs(u) * 190 + 20, Math.sin(a) * r * 190); }
  const sg = new THREE.BufferGeometry(); sg.setAttribute('position', new THREE.Float32BufferAttribute(sp, 3));
  stars = new THREE.Points(sg, new THREE.PointsMaterial({ color: 0xffffff, size: 2.2, sizeAttenuation: false, transparent: true, opacity: 0, fog: false }));
  scene.add(stars);

  peopleGroup = new THREE.Group(); guardGroup = new THREE.Group(); pickGroup = new THREE.Group(); mudGroup = new THREE.Group(); treeGroup = new THREE.Group();
  scene.add(peopleGroup, guardGroup, pickGroup, mudGroup, treeGroup);

  // jogador: ladrão com máscara, gorro e saco de loot
  playerM = makeHuman({ shirt: '#ff8f00', pants: '#23233d', shoes: '#101010', hair: 'beanie', hatColor: '#161616', mask: true, bag: true, gloves: '#161616', belt: '#333344', hairColor: '#2b1d12' });
  scene.add(playerM.group);
  pStars = makeStars(); pStars.position.y = 3.3; playerM.group.add(pStars);
  grabRing = new THREE.Mesh(new THREE.RingGeometry(1.5, 1.9, 32), new THREE.MeshBasicMaterial({ color: 0xff4a4a, transparent: true, opacity: 0.9, side: THREE.DoubleSide, blending: THREE.AdditiveBlending, depthWrite: false }));
  grabRing.rotation.x = -Math.PI / 2; grabRing.visible = false; scene.add(grabRing);
  arrow = new THREE.Group();
  const cg = new THREE.ConeGeometry(0.6, 1.6, 8); cg.rotateX(Math.PI / 2);
  arrow.add(new THREE.Mesh(cg, new THREE.MeshBasicMaterial({ color: 0xffe066 }))); scene.add(arrow);

  for (let i = 0; i < 24; i++) penPool.push({ rar: -1, m: null });
  initFX();
  floatBox = document.getElementById('floaters');
  resize();
}

function resize() {
  if (!renderer) return;
  const w = window.innerWidth, h = window.innerHeight;
  renderer.setSize(w, h, false);
  renderer.domElement.style.width = w + 'px'; renderer.domElement.style.height = h + 'px';
  camera.aspect = w / h; baseFov = w / h < 1 ? 72 : 58;
  camera.fov = baseFov; camera.updateProjectionMatrix();
}

function syncMap(list, map, create, parent, visibleFn) {
  for (const it of list) {
    let o = map.get(it);
    if (!o) { o = create(it); map.set(it, o); parent.add(o.group || o); }
    if (visibleFn) visibleFn(it, o);
  }
  if (map.size !== list.length) {
    for (const [k, o] of map) if (!list.includes(k)) { parent.remove(o.group || o); map.delete(k); }
  }
}

function rebuildStatics() {
  if (!treesBuilt) { treesBuilt = true; buildTrees(treeGroup, G.trees); }
  if (mudRef !== G.mud) {
    mudRef = G.mud;
    while (mudGroup.children.length) mudGroup.remove(mudGroup.children[0]);
    for (const m of G.mud) {
      const a = new THREE.Mesh(new THREE.CircleGeometry(m.r * 0.05, 20), new THREE.MeshStandardMaterial({ color: 0x5a3b20, roughness: 0.4, metalness: 0.1 }));
      a.rotation.x = -Math.PI / 2; a.position.set(X(m.x), 0.34, Z(m.y)); a.scale.set(1, 0.7, 1); a.receiveShadow = true; mudGroup.add(a);
      const b = new THREE.Mesh(new THREE.RingGeometry(m.r * 0.05, m.r * 0.05 + 0.25, 20), new THREE.MeshBasicMaterial({ color: 0x8b6a3d, side: THREE.DoubleSide }));
      b.rotation.x = -Math.PI / 2; b.position.set(X(m.x), 0.35, Z(m.y)); b.scale.set(1, 0.7, 1); mudGroup.add(b);
    }
  }
}

function floaters() {
  const list = G.texts;
  while (floatPool.length < list.length) { const d = document.createElement('div'); d.className = 'float'; floatBox.appendChild(d); floatPool.push(d); }
  for (let i = 0; i < floatPool.length; i++) {
    const d = floatPool[i], f = list[i];
    if (!f) { d.style.display = 'none'; continue; }
    vtmp.set(X(f.x), 3.8 + (1.2 - f.life) * 3, Z(f.y)); vtmp.project(camera);
    d.style.display = 'block';
    d.style.left = ((vtmp.x * 0.5 + 0.5) * window.innerWidth) + 'px';
    d.style.top = ((-vtmp.y * 0.5 + 0.5) * window.innerHeight) + 'px';
    d.style.opacity = Math.min(1, f.life); d.style.color = f.c; d.textContent = f.t;
    d.style.transform = 'translate(-50%,-50%) scale(' + (1 + Math.max(0, f.life - 0.9) * 2.5) + ')';
  }
}

// ---------- quadro ----------
function draw() {
  if (!renderer) return;
  const t = G.time, p = G.p, dt = Math.min(0.05, Math.max(0.001, t - lastT)); lastT = t;
  rebuildStatics();
  const psp = Math.hypot(p.vx, p.vy), run = p.dashing || psp > 250;

  // ===== pessoas da fase =====
  syncMap(G.people, peopleMap, createPerson, peopleGroup, (per, m) => {
    const carried = G.carrying === per, grabbed = G.grabbing === per;
    const dx = p.x - per.x, dz = p.y - per.y, d = Math.hypot(dx, dz);
    m.group.visible = (!per.taken || carried) && (carried || d < 1700);   // longe demais: nem anima
    if (!m.group.visible) return;
    if (carried) {
      m.carryT = Math.min(1, m.carryT + dt * 3.2);
      if (m.carryT <= dt * 3.3) m.liftFrom.copy(m.group.position);
      const fx = Math.sin(playerAng), fz = Math.cos(playerAng), e = easeOutBack(m.carryT);
      const tx = X(p.x) - fx * 1.25, ty = 2.95 + p.h, tz = Z(p.y) - fz * 1.25;
      m.group.position.set(m.liftFrom.x + (tx - m.liftFrom.x) * e, m.liftFrom.y + (ty - m.liftFrom.y) * e, m.liftFrom.z + (tz - m.liftFrom.z) * e);
      m.group.rotation.y = angLerp(m.group.rotation.y, playerAng, 0.3); m.group.scale.setScalar(0.9);
      animate(m, 'struggle', dt, { t, speed: 0 });
      m.ring.visible = false; m.label.visible = false; m.hint.visible = false; if (m.beam) m.beam.visible = false;
      return;
    }
    m.carryT = 0; m.group.scale.setScalar(1);
    m.group.position.set(X(per.x), 0.3, Z(per.y));
    const face = Math.atan2(dx, dz);
    let st = 'idle';
    if (grabbed) st = 'scared';
    else if (G.carrying && d < 420) st = 'scared';
    else if (d < 380) st = 'wave';
    if (d < 520) m.group.rotation.y = angLerp(m.group.rotation.y, face, st === 'scared' ? 0.25 : 0.06);
    animate(m, st, dt, { t, speed: 0, seed: per.id * 1.7, look: 0 });
    m.ring.visible = per.rar > 0; m.ring.rotation.z = t * 0.8; m.ring.scale.setScalar(1 + Math.sin(t * 3 + per.id) * 0.05);
    m.label.visible = d < 900; m.hint.visible = G.nearPerson === per; m.hint.position.y = 4.8 + Math.sin(t * 8) * 0.25;
    if (m.beam) { m.beam.visible = true; m.beam.rotation.y = t * 0.5; m.beam.material.opacity = (0.2 + per.rar * 0.03) * (0.85 + Math.sin(t * 3 + per.id) * 0.15); }
    if (per.rar >= 3 && d < 900 && t - sparkT > 0) { sparkT = t + 0.15; addPart(per.x + rand(-30, 30), per.y + rand(-30, 30), RARITIES[per.rar].c, 1, 15, 'sparkle'); }
  });

  // ===== guardas =====
  syncMap(G.guards, guardMap, createGuard, guardGroup, (g, m) => {
    const sp = Math.hypot(g.vx, g.vy), chase = g.state === 'chase', stunned = g.stun > 0;
    m.group.visible = Math.hypot(g.x - p.x, g.y - p.y) < 1700;
    if (!m.group.visible) return;
    m.group.position.set(X(g.x), 0.3, Z(g.y));
    if (!stunned && sp > 5) m.group.rotation.y = angLerp(m.group.rotation.y, Math.atan2(g.vx, g.vy), 0.2);
    else if (stunned) m.group.rotation.y = angLerp(m.group.rotation.y, Math.atan2(p.x - g.x, p.y - g.y), 0.3);
    let st = 'walk';
    if (stunned) st = 'scared'; else if (chase) st = 'run';
    animate(m, st, dt, { t, speed: Math.min(1.2, sp / 120), run: chase, expr: chase ? 'angry' : 'neutral' });
    m.mats.shirt.color.set(stunned ? 0x8a8f9c : chase ? 0xd63a3a : 0x2f55d6);
    m.bang.visible = chase && !stunned; m.bang.position.y = 3.9 + Math.sin(t * 12) * 0.12;
    m.stars.visible = g.stun > 1.0; if (m.stars.visible) spinStars(m.stars, t);
  });

  // ===== itens (moedas, turbo, escudo) =====
  syncMap(G.pickups, pickMap, createPickup, pickGroup, (it, o) => {
    o.group.position.set(X(it.x), 1.7 + Math.sin(it.t * 3) * 0.35, Z(it.y));
    o.group.userData.mesh.rotation.y = it.t * 2.2;
  });

  // ===== pessoas garantidas passeando no cercado =====
  const n = Math.min(24, save.pen.length);
  for (let i = 0; i < 24; i++) {
    const e = penPool[i];
    if (i >= n) { if (e.m) e.m.group.visible = false; continue; }
    const rar = save.pen[i];
    if (!e.m || e.rar !== rar) {
      if (e.m) scene.remove(e.m.group);
      const rc = RARITIES[rar];
      e.m = makeHuman({ skin: SKINS[i % 5], hairColor: HAIRS[(i * 3) % 6], hair: ['short', 'long', 'pony', 'beanie'][i % 4], hatColor: '#d94f6a', shirt: 'hsl(' + ((i * 47) % 360) + ',65%,55%)', pants: PANTS[i % 5], scarf: rar >= 1 ? rc.c : null, crown: rar >= 3, halo: rar >= 4, cape: rar >= 2 ? '#7a3fd0' : null });
      e.rar = rar; scene.add(e.m.group);
    }
    const col = i % 8, row = (i / 8) | 0, w = e.m;
    const x = 300 + col * 110 + Math.sin(t * 0.8 + i) * 25, y = CFG.penTop + 130 + row * 90 + Math.cos(t * 0.7 + i) * 15;
    w.group.visible = true; w.group.position.set(X(x), 0.5, Z(y));
    w.group.rotation.y = angLerp(w.group.rotation.y, Math.cos(t * 0.8 + i) > 0 ? 1.2 : -1.2, 0.05);
    animate(w, (i + Math.floor(t / 6)) % 3 === 0 ? 'dance' : 'walk', dt, { t, speed: 0.3, seed: i });
  }

  // ===== jogador =====
  const target = G.grabbing || G.nearPerson;
  if (G.grabbing) playerAng = angLerp(playerAng, Math.atan2(G.grabbing.x - p.x, G.grabbing.y - p.y), 0.3);
  else if (psp > 8) playerAng = angLerp(playerAng, Math.atan2(p.vx, p.vy), 0.25);
  let pst = 'idle';
  if (p.hit > 0) pst = 'down';
  else if (p.stun > 0) pst = 'scared';
  else if (G.grabbing) pst = 'grab';
  else if (p.h > 0.05) pst = 'jump';
  else if (p.cheer > 0) pst = 'cheer';
  else if (G.carrying) pst = 'carry';
  else if (psp > 12) pst = run ? 'run' : 'walk';
  const look = target ? Math.max(-0.7, Math.min(0.7, 0)) : 0;
  animate(playerM, pst, dt, { t, speed: Math.min(1.2, psp / 170), run, u: G.grabbing ? G.grabT / 0.55 : 0, vh: p.vh, look });
  playerM.group.position.set(X(p.x), 0.3 + p.h, Z(p.y));
  playerM.group.rotation.y = playerAng;
  pStars.visible = p.hit > 0.3; if (pStars.visible) spinStars(pStars, t);
  playerM.extras.bag.visible = !G.carrying;
  // anel de progresso do roubo + aura do alvo
  grabRing.visible = !!G.grabbing;
  if (G.grabbing) { const u = clamp01(G.grabT / 0.55); grabRing.position.set(X(G.grabbing.x), 0.5, Z(G.grabbing.y)); grabRing.scale.setScalar(1.6 - u * 0.7); grabRing.rotation.z = t * 6; grabRing.material.opacity = 0.4 + u * 0.6; }
  arrow.visible = !!G.carrying;
  if (G.carrying) {
    arrow.position.set(X(p.x), 6.6 + Math.sin(t * 6) * 0.2 + p.h, Z(p.y));
    arrow.rotation.y = Math.atan2(X(CFG.laneX) - X(p.x), Z(CFG.finishY) - Z(p.y));
  }
  drawFX(t);

  // ===== céu: dia -> pôr do sol -> noite =====
  const u = (Math.sin(t / 40) + 1) / 2;
  let n1 = 0, dk = 0;                       // n1: noite, dk: crepúsculo
  if (u > 0.4 && u <= 0.6) dk = (u - 0.4) / 0.2; else if (u > 0.6 && u <= 0.8) { dk = 1 - (u - 0.6) / 0.2; n1 = (u - 0.6) / 0.2; } else if (u > 0.8) n1 = 1;
  tmpCol.copy(dayCol).lerp(duskCol, Math.min(1, dk + n1 * 0.0)).lerp(nightCol, n1);
  scene.background.copy(tmpCol); scene.fog.color.copy(tmpCol);
  hemi.intensity = 1.1 - n1 * 0.75; sun.intensity = 2.4 - n1 * 2.0;
  sun.color.copy(sunDay).lerp(sunDusk, dk);
  refs.bulbMat.color.setHex(n1 > 0.3 ? 0xffe27a : 0xcfc9a0);
  for (const f of refs.flames) f.scale.setScalar(1 + Math.sin(t * 14 + f.position.x) * 0.12);
  refs.clouds.position.x = (t * 0.6) % 40 - 20;
  refs.water.offset.set(t * 0.012, t * 0.008);
  refs.foam.forEach((m, i) => { m.opacity = 0.25 + Math.sin(t * 1.4 + i * 1.7) * 0.12; });

  // ===== câmera orbital + efeitos =====
  const D = 15, H = 9.5, tx = X(p.x), tz = Z(p.y);
  const wantX = tx + Math.sin(camYaw) * D, wantZ = tz + Math.cos(camYaw) * D;
  if (camPos.lengthSq() === 0) camPos.set(wantX, H, wantZ);
  camPos.x += (wantX - camPos.x) * 0.18; camPos.z += (wantZ - camPos.z) * 0.18; camPos.y = H;
  const sh = G.shake > 0 ? 0.4 : 0;
  camera.position.set(camPos.x + (Math.random() - 0.5) * sh, camPos.y + p.h * 0.3, camPos.z + (Math.random() - 0.5) * sh);
  camera.lookAt(tx, 2.2, tz);
  const wantFov = baseFov + (p.dashing ? 7 : 0) + (G.carrying ? 2 : 0);
  if (Math.abs(camera.fov - wantFov) > 0.05) { camera.fov += (wantFov - camera.fov) * 0.12; camera.updateProjectionMatrix(); }
  // sol/lua/estrelas acompanham a câmera; sombras acompanham o jogador
  sun.position.set(tx + 30, 55, tz + 18); sun.target.position.set(tx, 0, tz);
  sunGlow.position.set(camera.position.x + 90, 80 - n1 * 40, camera.position.z - 150); sunGlow.material.opacity = 0.95 * (1 - n1);
  moonGlow.position.set(camera.position.x - 70, 90, camera.position.z - 150); moonGlow.material.opacity = 0.85 * n1;
  stars.position.copy(camera.position); stars.material.opacity = n1;
  floaters();
  renderer.render(scene, camera);
}

function setQuality(q) { try { localStorage.setItem('rep-quality', String(q)); } catch (e) {} location.reload(); }
function testPoses() { return selfTest(makeHuman({ shirt: '#fff', mask: true, bag: true, crown: true, halo: true, cape: '#f0f', scarf: '#0f0', shades: true, hair: 'pony' })); }

window.R3D = { init, resize, draw, getQuality, setQuality, qualityName: () => QNAMES[getQuality()], testPoses };
window.addEventListener('resize', resize);
