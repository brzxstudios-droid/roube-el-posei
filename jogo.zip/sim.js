'use strict';
// ===== Roube el Posei - simulação por frame =====
function update(dt) {
  G.time += dt;
  const p = G.p, inp = readInput();
  if (G.bannerT > 0) G.bannerT -= dt;
  if (G.shake > 0) G.shake -= dt;

  // ----- jogador -----
  if (p.stun > 0) p.stun -= dt;
  const moving = Math.hypot(inp.x, inp.y) > 0.1;
  let spd = playerSpeed();
  if (G.carrying) spd *= 0.8 - RARITIES[G.carrying.rar].v / 1000 * 0.05; // pessoas valiosas pesam mais
  if (p.boost > 0) { p.boost -= dt; spd *= 1.35; }
  if (p.h < 0.5) for (const m of G.mud) if (Math.hypot(p.x - m.x, p.y - m.y) < m.r) { spd *= 0.55; break; }  // pulando sobre a lama não atrasa
  p.dashing = inp.dash && moving && p.stamina > 0 && p.stun <= 0;
  if (p.dashing) { spd *= 1.6; p.stamina = Math.max(0, p.stamina - 35 * dt); if (Math.random() < 0.5) addPart(p.x, p.y + 10, '#e8dcc0', 1, 40, 'dust'); }
  else if (moving && p.h < 0.1 && Math.random() < 0.12) addPart(p.x, p.y + 10, '#e8dcc0', 1, 25, 'dust');
  else p.stamina = Math.min(maxStamina(), p.stamina + 18 * dt);
  if (p.stun <= 0) {
    p.vx += (inp.x * spd - p.vx) * Math.min(1, dt * 12);
    p.vy += (inp.y * spd - p.vy) * Math.min(1, dt * 12);
  } else { p.vx *= 0.8; p.vy *= 0.8; }
  p.x += p.vx * dt; p.y += p.vy * dt;
  if (Math.abs(inp.x) > 0.1) p.face = inp.x > 0 ? 1 : -1;
  p.steps += Math.hypot(p.vx, p.vy) * dt * 0.05;
  clampToIsland(p);

  // ----- pulo (visual + passa por cima da lama) e timers de animação -----
  if (inp.jump && !p.jumpLatch && p.h <= 0.01 && p.stun <= 0 && p.hit <= 0) { p.vh = 9.5; p.jumpLatch = true; vibrate(15); addPart(p.x, p.y + 10, '#e8dcc0', 4, 60, 'dust'); }
  if (!inp.jump && p.h <= 0.01) p.jumpLatch = false;
  if (p.h > 0 || p.vh > 0) {
    p.vh -= 26 * dt; p.h += p.vh * dt;
    if (p.h <= 0) { p.h = 0; if (p.vh < -4) addPart(p.x, p.y + 10, '#e8dcc0', 5, 70, 'dust'); p.vh = 0; }
  }
  if (p.cheer > 0) p.cheer -= dt;
  if (p.hit > 0) p.hit -= dt;
  G.nearPad = null;
  if (!G.carrying) for (const k in CFG.pads) if (dist(p, CFG.pads[k]) < CFG.padR) G.nearPad = k;
  if (p.y > CFG.city.y0 + 20 && !G.inCity) { G.inCity = true; banner('Mini Cidade 🏙️', '#7fd7ff'); }
  else if (p.y < CFG.city.y0 - 150) G.inCity = false;
  G.nearPerson = null;
  if (!G.carrying) for (const per of G.people) if (!per.taken && dist(p, per) < 70) { G.nearPerson = per; break; }

  // ----- roubar (segura o botão perto de uma pessoa) -----
  if (!G.carrying && p.stun <= 0) {
    let near = null, nd = 70;
    for (const per of G.people) {
      if (per.taken) continue;
      const d = dist(p, per);
      if (d < nd) { nd = d; near = per; }
    }
    if (near && inp.act) {
      if (G.grabbing !== near) { G.grabbing = near; G.grabT = 0; }
      G.grabT += dt;
      // guardas percebem o roubo quando ele está quase completo
      if (G.grabT > 0.35) for (const g of G.guards) if (g.home === near && g.state === 'patrol' && dist(g, p) < 160) g.state = 'chase';
      if (G.grabT >= 0.55) {
        G.carrying = near; near.taken = true; G.grabbing = null;
        SFX.grab(); SFX.alarm(); vibrate(60); G.alarm = 1;
        addPart(near.x, near.y, RARITIES[near.rar].c, 20);
        banner('CORRE! Leva até a linha de chegada!');
        // guardas levam um susto (0,8s) e depois perseguem: dá tempo de arrancar
        for (const g of G.guards) if (g.home === near) { g.state = 'chase'; g.stun = 0.8; g.scare = 0.8; }
      }
    } else { G.grabbing = null; G.grabT = 0; }
  } else { G.grabbing = null; G.grabT = 0; }

  if (G.carrying) {
    G.carrying.x = p.x - p.face * 18; G.carrying.y = p.y - 6;
    if (p.y > CFG.finishY && G.carrying) secure();
  }

  // ----- guardas -----
  const gs = guardSpeed();
  for (const g of G.guards) {
    if (g.stun > 0) { g.stun -= dt; continue; }
    const per = g.home;
    let tx, ty, sp = gs * 0.45;
    if (g.state === 'patrol') {
      g.ang += dt * (0.8 + save.level * 0.04);
      tx = per.hx + Math.cos(g.ang) * g.orb; ty = per.hy + Math.sin(g.ang) * g.orb;
      // furtivo: só nota de bem perto; correr faz barulho e alerta de mais longe
      const veh = vehicle(), dp = dist(g, p), notice = (p.dashing || (veh && veh.noisy)) ? 190 : 62;
      if (!G.carrying && dp < notice && !inSafe(p) && p.stun <= 0) g.state = 'chase';
    } else if (g.state === 'chase') {
      if (inSafe(p) || p.stun > 0 || (!G.carrying && dist(g, p) > 340)) { g.state = 'return'; }
      tx = p.x; ty = p.y; sp = gs;
      // quem não tem a pessoa roubada persegue um pouco mais devagar
      if (G.carrying !== per) sp *= 0.85;
    } else { // return
      tx = per.hx; ty = per.hy; sp = gs * 0.7;
      if (Math.hypot(g.x - tx, g.y - ty) < 80) g.state = 'patrol';
    }
    const dx = tx - g.x, dy = ty - g.y, d = Math.hypot(dx, dy) || 1;
    g.vx = dx / d * sp; g.vy = dy / d * sp;
    g.x += g.vx * dt; g.y += g.vy * dt;
    if (g.y > CFG.finishY - 10) g.y = CFG.finishY - 10;   // cercado é zona segura
    clampToIsland(g);
    if (g.state === 'chase' && dist(g, p) < g.r + p.r - 2) caught(g);
  }

  // ----- itens -----
  for (let i = G.pickups.length - 1; i >= 0; i--) {
    const it = G.pickups[i]; it.t += dt;
    if (Math.hypot(it.x - p.x, it.y - p.y) < 30) {
      if (it.kind === 'boost') { p.boost = 6; addText(p.x, p.y - 30, 'Turbo!', '#ffe066'); }
      else if (it.kind === 'shield') { p.shield = Math.min(6, p.shield + 1); addText(p.x, p.y - 30, '+Escudo', '#7ad7ff'); }
      else { const v = 15 + save.level * 8; save.coins += v; addText(p.x, p.y - 30, '+' + v + ' 🪙', '#ffe066'); p.cheer = 0.7; addPart(it.x, it.y, '#ffc400', 8, 160, 'coin'); persist(); }
      SFX.power(); addPart(it.x, it.y, it.kind === 'boost' ? '#ffe066' : it.kind === 'shield' ? '#7ad7ff' : '#ffffff', 14); addPart(it.x, it.y, '#ffffff', 1, 0, 'ring'); G.pickups.splice(i, 1);
    }
  }

  // ----- renda passiva do cercado -----
  save.coins += incomePerSec() * dt;
  if (Math.floor(G.time) % 10 === 0 && Math.floor(G.time - dt) % 10 !== 0) persist();

  // ----- partículas / textos -----
  for (let i = G.parts.length - 1; i >= 0; i--) {
    const q = G.parts[i]; q.life -= dt; q.x += q.vx * dt; q.y += q.vy * dt; q.vx *= 0.94; q.vy *= 0.94;
    if (q.kind === 'spark' || q.kind === 'coin') { q.vh -= 16 * dt; q.h += q.vh * dt; if (q.h < 0.3) { q.h = 0.3; q.vh *= -0.45; } }
    else if (q.kind !== 'ring') q.h += q.vh * dt * 0.5;
    if (q.life <= 0) G.parts.splice(i, 1);
  }
  for (let i = G.texts.length - 1; i >= 0; i--) {
    const t = G.texts[i]; t.life -= dt; t.y -= 30 * dt; if (t.life <= 0) G.texts.splice(i, 1);
  }
}

// mantém dentro da ilha (retângulo arredondado)
// áreas andáveis: ilha -> ponte (estreita) -> cidade; blocos de prédios são obstáculos
function clampToIsland(o) {
  const C = CFG.city, onBridgeX = Math.abs(o.x - CFG.laneX) <= CFG.bridgeHalf - 15;
  if (o.y <= 2860) {                                   // ilha do cercado
    o.x = clamp(o.x, 140, MAP.w - 140); o.y = Math.max(200, o.y);
  } else if (o.y < C.y0 + 40) {                        // ponte
    if (onBridgeX) { /* ok */ }
    else if (Math.abs(o.x - CFG.laneX) <= CFG.bridgeHalf + 10 && o.y > 2870 && o.y < C.y0 - 20)
      o.x = clamp(o.x, CFG.laneX - CFG.bridgeHalf + 15, CFG.laneX + CFG.bridgeHalf - 15);   // desliza pela borda da ponte
    else if (o.y < 3130) o.y = 2860;                   // fora do vão do portão: volta para o cercado
    else o.y = C.y0 + 40;                              // fora da ponte, lado da cidade: fica na cidade
  }
  if (o.y >= C.y0 + 40) {                              // cidade
    o.x = clamp(o.x, C.x0 + 40, C.x1 - 40); o.y = Math.min(o.y, C.y1 - 50);
    for (const b of CFG.blocks) {
      const m = 18;
      if (o.x > b[0] - m && o.x < b[2] + m && o.y > b[1] - m && o.y < b[3] + m) {
        const dl = o.x - (b[0] - m), dr = (b[2] + m) - o.x, dt = o.y - (b[1] - m), db = (b[3] + m) - o.y, mn = Math.min(dl, dr, dt, db);
        if (mn === dl) o.x = b[0] - m; else if (mn === dr) o.x = b[2] + m; else if (mn === dt) o.y = b[1] - m; else o.y = b[3] + m;
      }
    }
  }
}
