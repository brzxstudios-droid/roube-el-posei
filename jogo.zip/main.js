'use strict';
// ===== Roube el Posei - multiplayer (cliente) =====
// Endereço do servidor: pode ser colocado aqui (ex.: 'wss://meu-servidor.onrender.com') ou digitado na tela 🌐.
const NET_DEFAULT_SERVER = '';
const NET = {
  on: false, want: false, ws: null, id: 0, room: '', pub: false,
  remote: new Map(), roster: [], top: [], toasts: [], status: 'Desconectado', err: '',
  sendT: 0, lastSent: '', keepT: 0, pingT: 0, retry: 0, retryT: 0, fseq: 0, onUI: null,
  url: '', name: '', uid: '', hue: 0
};
(function () {
  const ls = (k, v) => { try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, v); } catch (e) {} return null; };
  NET.uid = ls('rep-uid') || ('u' + Math.random().toString(36).slice(2, 10) + Date.now().toString(36)); ls('rep-uid', NET.uid);
  NET.name = ls('rep-name') || ('Ladrão' + ((Math.random() * 900 + 100) | 0));
  NET.url = ls('rep-server') || NET_DEFAULT_SERVER;
  NET.hue = parseInt(ls('rep-hue'), 10); if (!(NET.hue >= 0)) { NET.hue = (Math.random() * 360) | 0; ls('rep-hue', String(NET.hue)); }
  NET.lastRoom = ls('rep-room') || '';
  NET.store = ls;
})();

function netNorm(u) {
  u = String(u || '').trim();
  if (!u) return '';
  if (/^https?:\/\//i.test(u)) u = u.replace(/^http/i, 'ws');
  if (!/^wss?:\/\//i.test(u)) u = 'wss://' + u;
  return u;
}
NET.connect = function (url, room, name) {
  NET.url = netNorm(url); NET.name = String(name || NET.name).slice(0, 12) || NET.name; NET.lastRoom = String(room || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6);
  NET.store('rep-server', NET.url); NET.store('rep-name', NET.name); NET.store('rep-room', NET.lastRoom);
  if (!NET.url) { NET.err = 'Digite o endereço do servidor.'; NET.status = 'Desconectado'; return NET.ui(); }
  NET.want = true; NET.retry = 0; NET.open();
};
NET.open = function () {
  NET.close(true); NET.err = ''; NET.status = 'Conectando…'; NET.ui();
  let ws;
  try { ws = new WebSocket(NET.url); } catch (e) { NET.err = 'Endereço inválido.'; NET.status = 'Desconectado'; NET.want = false; return NET.ui(); }
  NET.ws = ws;
  ws.onopen = () => { NET.retry = 0; ws.send(JSON.stringify({ t: 'join', room: NET.lastRoom, name: NET.name, uid: NET.uid, hue: NET.hue })); };
  ws.onmessage = e => { try { NET.msg(JSON.parse(e.data)); } catch (er) {} };
  ws.onerror = () => { if (ws === NET.ws) NET.err = 'Não consegui conectar. Confira o endereço (precisa começar com wss://).'; };
  ws.onclose = () => {
    if (ws !== NET.ws) return;
    NET.on = false; NET.ws = null; NET.remote.clear(); NET.roster = [];
    if (NET.want) { NET.status = 'Reconectando…'; NET.retryT = Math.min(15, 2 + NET.retry * 2); NET.retry++; }
    else NET.status = 'Desconectado';
    NET.ui();
  };
};
NET.close = function (keepWant) {
  if (!keepWant) NET.want = false;
  const w = NET.ws; NET.ws = null; NET.on = false;
  if (w) { try { w.onclose = null; w.close(); } catch (e) {} }
  NET.remote.clear(); NET.roster = []; NET.room = '';
};
NET.leave = function () { NET.close(false); NET.status = 'Desconectado'; NET.err = ''; NET.ui(); };
NET.send = function (o) { if (NET.ws && NET.ws.readyState === 1) NET.ws.send(JSON.stringify(o)); };
NET.ui = function () { if (NET.onUI) NET.onUI(); };
NET.toast = function (m) { if (typeof banner === 'function') banner(m, '#ffe066'); };

NET.pen = function () { const c = [0, 0, 0, 0, 0]; for (const r of save.pen) c[r]++; return c; };
NET.sendStat = function () { NET.send({ t: 'stat', c: save.coins, s: save.stolen, l: save.level, pen: NET.pen() }); };

NET.msg = function (m) {
  switch (m.t) {
    case 'joined':
      NET.on = true; NET.id = m.id; NET.room = m.room; NET.pub = m.pub; NET.status = 'Online'; NET.lastSent = ''; NET.keepT = 99;
      NET.sendStat(); NET.ui(); NET.toast('🌐 Sala ' + (m.pub ? 'pública' : m.room)); break;
    case 'st':
      for (const a of m.p) {
        if (a[0] === NET.id) continue;
        let r = NET.remote.get(a[0]);
        if (!r) {
          const ro = NET.roster.find(q => q.id === a[0]);
          r = { id: a[0], name: ro ? ro.n : 'Jogador', hue: ro ? ro.hue : (a[0] * 67) % 360, x: a[1], y: a[2], ang: 0, snap: true };
          NET.remote.set(a[0], r);
        }
        r.tx = a[1]; r.ty = a[2]; r.f = a[3]; r.h = a[4]; r.d = a[5]; r.v = a[6]; r.c = a[7]; r.s = a[8]; r.seen = G.time;
        if (r.snap) { r.x = r.tx; r.y = r.ty; r.snap = false; }
      }
      break;
    case 'gone': NET.remote.delete(m.id); break;
    case 'ros':
      NET.roster = m.p;
      for (const q of m.p) { const r = NET.remote.get(q.id); if (r) { r.name = q.n; r.hue = q.hue; } }
      NET.ui(); break;
    case 'top': NET.top = m.g; NET.ui(); break;
    case 'msg': NET.toast(m.m); break;
    case 'err': NET.err = m.m; NET.ui(); NET.toast('⚠️ ' + m.m); break;
    case 'robbed': {
      const i = save.pen.lastIndexOf(m.rar);
      if (i >= 0) save.pen.splice(i, 1);
      persist(); NET.sendStat(); SFX.hit(); vibrate(150); G.shake = 0.35;
      banner('🏴‍☠️ ' + m.by + ' roubou um ' + RARITIES[m.rar].n + ' do seu cercado!', '#ff7a7a'); break;
    }
    case 'raidok':
      save.pen.push(m.rar); if (save.pen.length > 80) save.pen.shift();
      persist(); NET.sendStat(); SFX.coin(); vibrate(60);
      addPart(G.p.x, G.p.y, RARITIES[m.rar].c, 24, 200); addPart(G.p.x, G.p.y, '#ffc400', 14, 220, 'coin'); addPart(G.p.x, G.p.y, RARITIES[m.rar].c, 1, 0, 'ring');
      G.p.cheer = 1.4; banner('🏴‍☠️ Assalto! ' + RARITIES[m.rar].n + ' de ' + m.from, RARITIES[m.rar].c); NET.ui(); break;
    case 'raidfail': banner('❌ ' + m.m, '#ff9a7a'); NET.ui(); break;
    case 'caught': G.p.stun = 1.6; G.p.hit = 1.2; SFX.hit(); vibrate(200); G.shake = 0.4; break;
    case 'tackled':
      if (G.carrying) dropCarried('Roubaram de você!');
      G.p.stun = 0.8; SFX.hit(); vibrate(150); G.shake = 0.3; banner('💥 ' + m.by + ' roubou seu Posei!', '#ff7a7a'); break;
    case 'tackleok': {
      if (G.carrying) break;
      const per = { x: G.p.x, y: G.p.y, hx: G.p.x, hy: G.p.y, r: 18, rar: m.rar, name: 'Roubado', hue: (Math.random() * 360) | 0, taken: true, id: 5000 + (NET.fseq++), foreign: true };
      G.people.push(per); G.carrying = per; SFX.grab(); SFX.alarm(); vibrate(60);
      addPart(G.p.x, G.p.y, RARITIES[m.rar].c, 20);
      banner('💥 Você roubou de ' + m.from + '! Corre pro cercado!', RARITIES[m.rar].c); break;
    }
  }
};
NET.raid = function (id) {
  if (!NET.on) return;
  if (G.p.y < CFG.penTop || G.p.y > CFG.penBottom) { banner('Entre no cercado 🏁 para assaltar!', '#ff9a7a'); return; }
  NET.send({ t: 'raid', to: id });
};
// perto de um jogador que carrega um Posei? ROUBAR pega dele
NET.tackleTarget = function () {
  if (!NET.on || G.carrying) return null;
  for (const r of NET.remote.values()) if (r.c >= 0 && Math.hypot(r.tx - G.p.x, r.ty - G.p.y) < 75) return r;
  return null;
};
NET.tryTackle = function (r) { if (NET.tackleT > G.time) return; NET.tackleT = G.time + 1.2; NET.send({ t: 'tackle', to: r.id }); };
NET.tackleT = 0;

// chamado todo quadro (mesmo pausado): envia a posição ~10x/s e cuida de reconexão/keepalive
NET.tick = function (dt) {
  if (NET.want && !NET.ws) { NET.retryT -= dt; if (NET.retryT <= 0) NET.open(); }
  if (!NET.on || !G.p) return;
  NET.sendT += dt; NET.keepT += dt; NET.pingT += dt;
  if (NET.pingT > 20) { NET.pingT = 0; NET.send({ t: 'ping' }); }
  if (NET.sendT < 0.1) return;
  NET.sendT = 0;
  const p = G.p, s = p.hit > 0 ? 1 : p.stun > 0 ? 2 : (p.cheer > 0 && !G.carrying) ? 3 : 0;
  const v = (G.grabbing || s) ? '' : (save.equip === 'scooter' ? 's' : save.equip === 'moto' ? 'm' : '');
  const msg = { t: 'pos', x: Math.round(p.x), y: Math.round(p.y), f: p.face, h: +p.h.toFixed(1), d: p.dashing ? 1 : 0, v, c: G.carrying ? G.carrying.rar : -1, s };
  const key = JSON.stringify(msg);
  if (key !== NET.lastSent || NET.keepT > 1) { NET.lastSent = key; NET.keepT = 0; NET.send(msg); }
  NET.statT = (NET.statT || 0) + 0.1;
  if (NET.statT > 3) { NET.statT = 0; NET.sendStat(); }
};

// ===== Roube el Posei 3D - loop principal, HUD e loja =====
const $ = id => document.getElementById(id);

let lastCoins = 0;
function hud() {
  const p = G.p;
  $('coins').textContent = fmt(save.coins);
  $('lvl').textContent = save.level;
  $('prog').textContent = G.stolenThisLevel + '/' + G.totalThisLevel;
  $('inc').textContent = '+' + incomePerSec().toFixed(1) + '/s';
  $('stamFill').style.width = (p.stamina / maxStamina() * 100) + '%';
  $('shield').textContent = p.shield > 0 ? '🛡️×' + p.shield : '';
  $('shield').style.display = p.shield > 0 ? 'flex' : 'none';
  $('boost').textContent = p.boost > 0 ? '⚡' + p.boost.toFixed(0) + 's' : '';
  $('boost').style.display = p.boost > 0 ? 'flex' : 'none';
  // moedas: "pop" quando entra uma quantia relevante (não a renda contínua)
  const c = Math.floor(save.coins);
  if (c - lastCoins > 4 + incomePerSec() * 0.2) { const el = $('coinChip'); el.classList.remove('pop'); void el.offsetWidth; el.classList.add('pop'); }
  lastCoins = c;
  // aviso central (cor da raridade)
  const b = $('banner');
  b.textContent = G.banner; b.style.color = G.bannerC || '#fff'; b.style.opacity = G.bannerT > 0 ? Math.min(1, G.bannerT) : 0;
  b.style.transform = 'scale(' + (1 + Math.max(0, G.bannerT - 1.9) * 1.5) + ')';
  // botão ROUBAR: acende quando há alguém ao alcance, anel mostra o progresso
  const act = $('btnAct'), prog = G.grabbing ? Math.min(100, G.grabT / 0.55 * 100) : 0;
  act.classList.toggle('ready', !!G.nearPerson && !G.grabbing);
  act.classList.toggle('busy', !!G.carrying);
  $('actRing').style.setProperty('--p', prog); $('actRing').style.setProperty('--c', '#ffe066');
  $('actLbl').textContent = G.carrying ? 'CORRE!' : G.grabbing ? 'SEGURA!' : G.nearPerson ? 'ROUBAR!' : 'ROUBAR';
  $('actIco').textContent = G.carrying ? '🏃' : G.grabbing ? '🤏' : '✋';
  // botão CORRER: anel = energia
  const sp = p.stamina / maxStamina() * 100;
  $('dashRing').style.setProperty('--p', sp); $('dashRing').style.setProperty('--c', sp < 15 ? '#ff5a4a' : '#ffe066');
  $('stam').classList.toggle('low', sp < 15);
  // vermelho de alerta enquanto carrega alguém
  $('alertFx').style.opacity = G.carrying ? (0.35 + 0.25 * Math.sin(G.time * 8)) : 0;
  const use = $('btnUse');
  use.style.display = G.nearPad ? 'flex' : 'none';
  if (G.nearPad) { use.textContent = PAD_TXT[G.nearPad]; use.dataset.kind = G.nearPad; }
  const nc = $('netChip');
  if (NET.on) { nc.style.display = 'flex'; nc.textContent = '🌐 ' + (NET.pub ? 'Pública' : NET.room) + ' · ' + (NET.remote.size + 1); } else nc.style.display = 'none';
  const tg = NET.tackleTarget();
  if (tg && !G.nearPerson) { $('actLbl').textContent = 'TACKLE!'; act.classList.add('ready'); }
  drawMini();
}

// minimapa vertical: ilha -> ponte -> cidade
const mini = $('mini'), mctx = mini.getContext('2d');
function drawMini() {
  const w = mini.width, h = mini.height, sx = w / 1300, sy = h / 4300, ox = 80, oy = 130;
  const X = x => (x - ox) * sx, Y = y => (y - oy) * sy, C = CFG.city;
  mctx.clearRect(0, 0, w, h);
  mctx.fillStyle = '#3f9f55'; mctx.fillRect(X(110), Y(170), (1290 - 110) * sx, (2890 - 170) * sy);
  mctx.fillStyle = '#c9a56b'; mctx.fillRect(X(CFG.laneX - CFG.laneW / 2), Y(200), CFG.laneW * sx, (CFG.penTop - 200) * sy);
  mctx.fillStyle = '#7fcf6a'; mctx.fillRect(X(200), Y(CFG.penTop), 1000 * sx, (CFG.penBottom - CFG.penTop) * sy);
  mctx.fillStyle = '#fff'; mctx.fillRect(X(CFG.laneX - 160), Y(CFG.finishY) - 2, 320 * sx, 4);
  mctx.fillStyle = '#9a9ca4'; mctx.fillRect(X(CFG.laneX - 100), Y(2900), 200 * sx, (C.y0 - 2900) * sy);            // ponte
  mctx.fillStyle = '#d6cfbe'; mctx.fillRect(X(C.x0), Y(C.y0), (C.x1 - C.x0) * sx, (C.y1 - C.y0) * sy);               // cidade
  mctx.fillStyle = '#4a4e57'; mctx.fillRect(X(560), Y(C.y0), 280 * sx, (C.y1 - C.y0) * sy);
  mctx.fillStyle = '#8b6b5a'; for (const bk of CFG.blocks) mctx.fillRect(X(bk[0]), Y(bk[1]), (bk[2] - bk[0]) * sx, (bk[3] - bk[1]) * sy);
  mctx.fillStyle = '#ffd23a'; mctx.beginPath(); mctx.arc(X(CFG.pads.market.x), Y(CFG.pads.market.y), 4, 0, 6.28); mctx.fill();
  mctx.fillStyle = '#4ac8ff'; mctx.beginPath(); mctx.arc(X(CFG.pads.garage.x), Y(CFG.pads.garage.y), 4, 0, 6.28); mctx.fill();
  for (const per of G.people) if (!per.taken) { mctx.fillStyle = RARITIES[per.rar].c; mctx.beginPath(); mctx.arc(X(per.x), Y(per.y), 4 + per.rar, 0, 6.28); mctx.fill(); mctx.strokeStyle = '#000'; mctx.lineWidth = 1; mctx.stroke(); }
  for (const g of G.guards) { mctx.fillStyle = g.state === 'chase' ? '#ff2a2a' : '#4d6fff'; mctx.fillRect(X(g.x) - 2, Y(g.y) - 2, 4, 4); }
  for (const r of NET.remote.values()) { mctx.fillStyle = 'hsl(' + r.hue + ',80%,60%)'; mctx.beginPath(); mctx.arc(X(r.x), Y(r.y), 4, 0, 6.28); mctx.fill(); mctx.strokeStyle = r.c >= 0 ? '#ffe066' : '#fff'; mctx.lineWidth = 1.5; mctx.stroke(); }
  const p = G.p;
  mctx.fillStyle = '#ffb000'; mctx.beginPath(); mctx.arc(X(p.x), Y(p.y), 5, 0, 6.28); mctx.fill();
  mctx.strokeStyle = G.carrying ? '#ffe066' : '#fff'; mctx.lineWidth = 2; mctx.stroke();
}

// ===== Mini Cidade: mercado (vender) e garagem (comprar/equipar veículos) =====
const PAD_TXT = { market: '🪙 VENDER POSEIS', garage: '🛵 GARAGEM' };
function cityRow(left, rightEl) {
  const r = document.createElement('div'); r.className = 'crow';
  const l = document.createElement('div'); l.className = 'cl'; l.innerHTML = left; r.appendChild(l);
  if (rightEl) r.appendChild(rightEl); return r;
}
function cityBtn(label, enabled, fn, cls) {
  const b = document.createElement('button'); b.className = 'cbtn ' + (cls || ''); b.textContent = label; b.disabled = !enabled;
  b.onclick = fn; return b;
}
function renderCity(kind) {
  const box = $('cityBody'); box.innerHTML = '';
  $('cityCoins').textContent = fmt(save.coins);
  if (kind === 'market') {
    $('cityTitle').textContent = '🪙 Mercado dos Poseis';
    const counts = [0, 0, 0, 0, 0]; for (const r of save.pen) counts[r]++;
    let total = 0; counts.forEach((n, r) => { total += n * sellValue(r); });
    const info = document.createElement('p'); info.className = 'cinfo';
    info.textContent = save.pen.length ? 'Aqui cada Posei vale ' + SELL_MULT + '× o preço normal. Vendido, ele sai do cercado e para de render moedas.' : 'Seu cercado está vazio. Roube Poseis, garanta na linha de chegada e traga pra vender!';
    box.appendChild(info);
    counts.forEach((n, r) => {
      if (!n) return;
      const rc = RARITIES[r];
      box.appendChild(cityRow('<span class="dot" style="background:' + rc.c + '"></span><b>' + rc.n + '</b> <small>× ' + n + ' · 🪙 ' + fmt(sellValue(r)) + ' cada</small>',
        cityBtn('Vender 🪙 ' + fmt(n * sellValue(r)), true, () => { const o = sellPen(r); if (o) banner('Vendeu ' + o.n + '! +' + fmt(o.total) + ' 🪙', rc.c); renderCity('market'); })));
    });
    if (save.pen.length) box.appendChild(cityBtn('VENDER TUDO · 🪙 ' + fmt(total), true, () => { const o = sellPen(-1); if (o) banner('Vendeu ' + o.n + ' Poseis! +' + fmt(o.total) + ' 🪙', '#ffe066'); renderCity('market'); }, 'big2'));
  } else {
    $('cityTitle').textContent = '🛵 Garagem';
    const info = document.createElement('p'); info.className = 'cinfo';
    info.textContent = 'Veículos deixam você mais rápido. Para roubar você desce sozinho do veículo.'; box.appendChild(info);
    box.appendChild(cityRow('<span class="vi">🚶</span><b>A pé</b> <small>velocidade normal</small>',
      cityBtn(save.equip === 'none' ? 'EM USO ✓' : 'USAR', save.equip !== 'none', () => { equipVehicle('none'); renderCity('garage'); })));
    for (const v of VEHICLES) {
      const owned = save.veh[v.id];
      const btn = owned ? cityBtn(save.equip === v.id ? 'EM USO ✓' : 'EQUIPAR', save.equip !== v.id, () => { equipVehicle(v.id); renderCity('garage'); })
        : cityBtn('Comprar 🪙 ' + fmt(v.cost), save.coins >= v.cost, () => { if (buyVehicle(v.id)) banner(v.n + ' comprado! 🎉', '#7fd7ff'); renderCity('garage'); });
      box.appendChild(cityRow('<span class="vi">' + v.icon + '</span><b>' + v.n + '</b> <small>' + v.d + '</small>', btn));
    }
  }
}
function openCity(kind) { if (!kind) return; paused = true; $('btnUse').style.display = 'none'; $('city').style.display = 'flex'; renderCity(kind); }
function closeCity() { $('city').style.display = 'none'; paused = false; refreshVehBtn(); }
function refreshVehBtn() {
  const any = VEHICLES.some(v => save.veh[v.id]);
  $('btnVeh').style.display = any ? 'flex' : 'none';
  const cur = VEHICLES.find(v => v.id === save.equip);
  $('btnVeh').textContent = cur ? cur.icon : '🚶';
}
function cycleVehicle() {
  const opts = ['none'].concat(VEHICLES.filter(v => save.veh[v.id]).map(v => v.id));
  equipVehicle(opts[(opts.indexOf(save.equip) + 1) % opts.length]); refreshVehBtn();
}

// ===== Multiplayer: sala, jogadores, assalto e placar =====
function renderNet() {
  const live = NET.on, st = $('netStatus');
  st.textContent = NET.err ? NET.status + ' — ' + NET.err : (live ? '🟢 Online · sala ' + (NET.pub ? 'pública (' + NET.room + ')' : NET.room) : NET.status);
  st.className = 'nst ' + (live ? 'ok' : NET.err ? 'bad' : '');
  $('netForm').style.display = live ? 'none' : 'block'; $('netLive').style.display = live ? 'block' : 'none';
  if (!live) return;
  const box = $('netPlayers'); box.innerHTML = '';
  const list = NET.roster.slice().sort((a, b) => b.s - a.s || b.c - a.c), medals = ['🥇', '🥈', '🥉'];
  const inPen = G.p.y >= CFG.penTop && G.p.y <= CFG.penBottom;
  list.forEach((q, i) => {
    const me = q.id === NET.id, total = q.pen.reduce((a, b) => a + b, 0);
    const right = me ? null : cityBtn('🏴‍☠️ Assaltar (' + total + ')', total > 0, () => { NET.raid(q.id); }, 'red');
    box.appendChild(cityRow('<b>' + (medals[i] || (i + 1) + '.') + ' ' + q.n + (me ? ' (você)' : '') + '</b><small>🤏 ' + q.s + ' roubados · 🪙 ' + fmt(q.c) + ' · Fase ' + q.l + ' · 🏠 ' + total + ' no cercado</small>', right));
  });
  if (!inPen) { const w = document.createElement('p'); w.className = 'cinfo'; w.textContent = 'Para assaltar você precisa estar dentro do cercado (depois da linha 🏁).'; box.appendChild(w); }
  const tp = $('netTop'); tp.innerHTML = '';
  NET.top.forEach((q, i) => tp.appendChild(cityRow('<b>' + (medals[i] || (i + 1) + '.') + ' ' + q.n + '</b><small>🤏 ' + q.s + ' roubados · 🪙 ' + fmt(q.c) + ' · Fase ' + q.l + '</small>')));
  if (!NET.top.length) { const w = document.createElement('p'); w.className = 'cinfo'; w.textContent = 'Ainda sem placar.'; tp.appendChild(w); }
}
function openNet() { paused = true; $('netName').value = NET.name; $('netUrl').value = NET.url; $('netRoom').value = NET.lastRoom; $('net').style.display = 'flex'; NET.onUI = () => { if ($('net').style.display === 'flex') renderNet(); }; renderNet(); }
function closeNet() { $('net').style.display = 'none'; paused = false; }

function openShop() {
  $('shop').style.display = 'flex';
  const box = $('shopList'); box.innerHTML = '';
  for (const u of UPGRADES) {
    const lv = save.up[u.id], max = lv >= CFG.maxUp, cost = upCost(u);
    const el = document.createElement('button');
    el.className = 'item'; el.disabled = max || save.coins < cost;
    el.innerHTML = '<b>' + u.n + ' <small>nv ' + lv + '/' + CFG.maxUp + '</small></b><span>' + u.d + '</span><em>' + (max ? 'MÁX' : '🪙 ' + fmt(cost)) + '</em>';
    el.onclick = () => { if (save.coins >= cost && !max) { save.coins -= cost; save.up[u.id]++; persist(); SFX.power(); openShop(); } };
    box.appendChild(el);
  }
  $('shopCoins').textContent = fmt(save.coins);
}
function closeShop() { $('shop').style.display = 'none'; G.p.shield = Math.max(G.p.shield, Math.min(CFG.maxUp, save.up.shield)); G.p.stamina = maxStamina(); }

let last = 0, paused = true;
function loop(ts) {
  const dt = Math.min(0.05, (ts - last) / 1000 || 0); last = ts;
  if (!paused) update(dt); else G.time += dt;
  NET.tick(dt);
  try { window.R3D.draw(); } catch (e) { showError(e); return; }
  if (!paused) hud();
  requestAnimationFrame(loop);
}

function showError(e) {
  const d = $('err'); d.style.display = 'flex';
  d.querySelector('pre').textContent = String(e && e.stack || e);
}

function boot() {
  loadSave(); setupInput(); buildLevel();
  $('best').textContent = save.best;
  if (!window.R3D) { showError('Falha ao carregar o three.js (vendor/three.module.js). Veja o README.'); return; }
  try { window.R3D.init(); } catch (e) { showError(e); return; }
  $('play').onclick = () => { $('start').style.display = 'none'; paused = false; SFX.level(); };
  $('btnUse').onpointerdown = e => { e.preventDefault(); openCity($('btnUse').dataset.kind); };
  $('cityClose').onclick = closeCity;
  $('btnVeh').onclick = cycleVehicle; refreshVehBtn();
  $('btnNet').onclick = openNet; $('netClose').onclick = closeNet; $('netLeave').onclick = () => NET.leave();
  $('netGo').onclick = () => NET.connect($('netUrl').value, $('netRoom').value, $('netName').value.trim() || NET.name);
  $('btnShop').onclick = () => { paused = true; openShop(); };
  $('shopClose').onclick = () => { closeShop(); paused = false; };
  const qn = window.R3D.qualityName();
  $('btnQual').title = 'Qualidade: ' + qn;
  $('btnQual').onclick = () => {
    const q = window.R3D.getQuality(), nq = (q + 1) % 3, names = ['Baixa', 'Média', 'Alta'];
    if (confirm('Qualidade gráfica atual: ' + names[q] + '.\nMudar para ' + names[nq] + '? (o jogo reinicia a tela, o progresso fica salvo)')) window.R3D.setQuality(nq);
  };
  $('btnSound').onclick = () => { soundOn = !soundOn; $('btnSound').textContent = soundOn ? '🔊' : '🔇'; };
  $('reset').onclick = () => { if (confirm('Apagar todo o progresso?')) { localStorage.removeItem(SAVE_KEY); location.reload(); } };
  document.addEventListener('visibilitychange', () => { if (document.hidden) persist(); });
  requestAnimationFrame(loop);
}
window.addEventListener('load', boot);
