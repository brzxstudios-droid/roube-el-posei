'use strict';
// ===== Roube el Posei 3D - loop principal, HUD e loja =====
const $ = id => document.getElementById(id);

let lastCoins = 0;
function hud() {
  const p = G.p;
  $('coins').textContent = fmt(save.coins);
  $('lvl').textContent = save.level;
  $('prog').textContent = G.stolenThisLevel + '/' + G.totalThisLevel;
  $('inc').textContent = '+' + incomePerSec().toFixed(1) + '/s';
  $('stamFill').style.width = (p.stamina / maxStamina() * 100) + '%';
  $('shield').textContent = p.shield > 0 ? '🛡️×' + p.shield : '';
  $('shield').style.display = p.shield > 0 ? 'flex' : 'none';
  $('boost').textContent = p.boost > 0 ? '⚡' + p.boost.toFixed(0) + 's' : '';
  $('boost').style.display = p.boost > 0 ? 'flex' : 'none';
  // moedas: "pop" quando entra uma quantia relevante (não a renda contínua)
  const c = Math.floor(save.coins);
  if (c - lastCoins > 4 + incomePerSec() * 0.2) { const el = $('coinChip'); el.classList.remove('pop'); void el.offsetWidth; el.classList.add('pop'); }
  lastCoins = c;
  // aviso central (cor da raridade)
  const b = $('banner');
  b.textContent = G.banner; b.style.color = G.bannerC || '#fff'; b.style.opacity = G.bannerT > 0 ? Math.min(1, G.bannerT) : 0;
  b.style.transform = 'scale(' + (1 + Math.max(0, G.bannerT - 1.9) * 1.5) + ')';
  // botão ROUBAR: acende quando há alguém ao alcance, anel mostra o progresso
  const act = $('btnAct'), prog = G.grabbing ? Math.min(100, G.grabT / 0.55 * 100) : 0;
  act.classList.toggle('ready', !!G.nearPerson && !G.grabbing);
  act.classList.toggle('busy', !!G.carrying);
  $('actRing').style.setProperty('--p', prog); $('actRing').style.setProperty('--c', '#ffe066');
  $('actLbl').textContent = G.carrying ? 'CORRE!' : G.grabbing ? 'SEGURA!' : G.nearPerson ? 'ROUBAR!' : 'ROUBAR';
  $('actIco').textContent = G.carrying ? '🏃' : G.grabbing ? '🤏' : '✋';
  // botão CORRER: anel = energia
  const sp = p.stamina / maxStamina() * 100;
  $('dashRing').style.setProperty('--p', sp); $('dashRing').style.setProperty('--c', sp < 15 ? '#ff5a4a' : '#ffe066');
  $('stam').classList.toggle('low', sp < 15);
  // vermelho de alerta enquanto carrega alguém
  $('alertFx').style.opacity = G.carrying ? (0.35 + 0.25 * Math.sin(G.time * 8)) : 0;
  drawMini();
}

// minimapa vertical da ilha
const mini = $('mini'), mctx = mini.getContext('2d');
function drawMini() {
  const w = mini.width, h = mini.height, sx = w / 1300, sy = h / 2900, ox = 80, oy = 130;
  const X = x => (x - ox) * sx, Y = y => (y - oy) * sy;
  mctx.clearRect(0, 0, w, h);
  mctx.fillStyle = '#3f9f55'; mctx.fillRect(X(110), Y(170), (1290 - 110) * sx, (2890 - 170) * sy);
  mctx.fillStyle = '#c9a56b'; mctx.fillRect(X(CFG.laneX - CFG.laneW / 2), Y(200), CFG.laneW * sx, (CFG.penTop - 200) * sy);
  mctx.fillStyle = '#7fcf6a'; mctx.fillRect(X(200), Y(CFG.penTop), 1000 * sx, (CFG.penBottom - CFG.penTop) * sy);
  mctx.fillStyle = '#fff'; mctx.fillRect(X(CFG.laneX - 160), Y(CFG.finishY) - 2, 320 * sx, 4);
  for (const per of G.people) if (!per.taken) { mctx.fillStyle = RARITIES[per.rar].c; mctx.beginPath(); mctx.arc(X(per.x), Y(per.y), 4 + per.rar, 0, 6.28); mctx.fill(); mctx.strokeStyle = '#000'; mctx.lineWidth = 1; mctx.stroke(); }
  for (const g of G.guards) { mctx.fillStyle = g.state === 'chase' ? '#ff2a2a' : '#4d6fff'; mctx.fillRect(X(g.x) - 2, Y(g.y) - 2, 4, 4); }
  const p = G.p;
  mctx.fillStyle = '#ffb000'; mctx.beginPath(); mctx.arc(X(p.x), Y(p.y), 5, 0, 6.28); mctx.fill();
  mctx.strokeStyle = G.carrying ? '#ffe066' : '#fff'; mctx.lineWidth = 2; mctx.stroke();
}

function openShop() {
  $('shop').style.display = 'flex';
  const box = $('shopList'); box.innerHTML = '';
  for (const u of UPGRADES) {
    const lv = save.up[u.id], max = lv >= CFG.maxUp, cost = upCost(u);
    const el = document.createElement('button');
    el.className = 'item'; el.disabled = max || save.coins < cost;
    el.innerHTML = '<b>' + u.n + ' <small>nv ' + lv + '/' + CFG.maxUp + '</small></b><span>' + u.d + '</span><em>' + (max ? 'MÁX' : '🪙 ' + fmt(cost)) + '</em>';
    el.onclick = () => { if (save.coins >= cost && !max) { save.coins -= cost; save.up[u.id]++; persist(); SFX.power(); openShop(); } };
    box.appendChild(el);
  }
  $('shopCoins').textContent = fmt(save.coins);
}
function closeShop() { $('shop').style.display = 'none'; G.p.shield = Math.max(G.p.shield, Math.min(CFG.maxUp, save.up.shield)); G.p.stamina = maxStamina(); }

let last = 0, paused = true;
function loop(ts) {
  const dt = Math.min(0.05, (ts - last) / 1000 || 0); last = ts;
  if (!paused) update(dt); else G.time += dt;
  try { window.R3D.draw(); } catch (e) { showError(e); return; }
  if (!paused) hud();
  requestAnimationFrame(loop);
}

function showError(e) {
  const d = $('err'); d.style.display = 'flex';
  d.querySelector('pre').textContent = String(e && e.stack || e);
}

function boot() {
  loadSave(); setupInput(); buildLevel();
  $('best').textContent = save.best;
  if (!window.R3D) { showError('Falha ao carregar o three.js (vendor/three.module.js). Veja o README.'); return; }
  try { window.R3D.init(); } catch (e) { showError(e); return; }
  $('play').onclick = () => { $('start').style.display = 'none'; paused = false; SFX.level(); };
  $('btnShop').onclick = () => { paused = true; openShop(); };
  $('shopClose').onclick = () => { closeShop(); paused = false; };
  const qn = window.R3D.qualityName();
  $('btnQual').title = 'Qualidade: ' + qn;
  $('btnQual').onclick = () => {
    const q = window.R3D.getQuality(), nq = (q + 1) % 3, names = ['Baixa', 'Média', 'Alta'];
    if (confirm('Qualidade gráfica atual: ' + names[q] + '.\nMudar para ' + names[nq] + '? (o jogo reinicia a tela, o progresso fica salvo)')) window.R3D.setQuality(nq);
  };
  $('btnSound').onclick = () => { soundOn = !soundOn; $('btnSound').textContent = soundOn ? '🔊' : '🔇'; };
  $('reset').onclick = () => { if (confirm('Apagar todo o progresso?')) { localStorage.removeItem(SAVE_KEY); location.reload(); } };
  document.addEventListener('visibilitychange', () => { if (document.hidden) persist(); });
  requestAnimationFrame(loop);
}
window.addEventListener('load', boot);
