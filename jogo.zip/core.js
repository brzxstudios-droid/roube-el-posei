'use strict';
// ===== Roube el Posei - núcleo: constantes, save, som, controles =====
const MAP = { w: 1400, h: 4500 };
const CFG = {
  laneX: 700, laneW: 280,
  finishY: 2480,   // linha de chegada (entrada do cercado)
  penTop: 2480, penBottom: 2900,
  firstY: 2150, lastY: 380,
  maxUp: 5,
  // ---- Mini Cidade (ilha ao sul, ligada ao cercado por uma ponte) ----
  city: { x0: 250, y0: 3400, x1: 1150, y1: 4350 },
  bridgeHalf: 100,
  blocks: [[280, 3440, 500, 3780], [900, 3440, 1120, 3780], [280, 4060, 500, 4300], [900, 4060, 1120, 4300]],
  pads: { market: { x: 520, y: 3700 }, garage: { x: 880, y: 3700 } },
  padR: 70
};
const SELL_MULT = 5;     // vender no mercado paga 5x o valor base da pessoa
const VEHICLES = [
  { id: 'scooter', n: 'Patinete', d: '+25% de velocidade', cost: 200, mult: 1.25, icon: '🛴' },
  { id: 'moto',    n: 'Moto',     d: '+55% de velocidade (mas faz barulho: guardas te notam de longe)', cost: 900, mult: 1.55, icon: '🏍️', noisy: true }
];
const RARITIES = [
  { n: 'Comum',    c: '#9ad1ff', v: 10 },
  { n: 'Raro',     c: '#7dff9a', v: 30 },
  { n: 'Épico',    c: '#c78bff', v: 90 },
  { n: 'Lendário', c: '#ffd24a', v: 300 },
  { n: 'Mítico',   c: '#ff5d8f', v: 1000 }
];
const NAMES = ['Zé', 'Pedro', 'Maria', 'João', 'Lia', 'Beto', 'Nina', 'Caio', 'Duda', 'Tico', 'Raul', 'Bia', 'Léo', 'Gui', 'Posei'];
const UPGRADES = [
  { id: 'speed',   n: 'Tênis veloz',    d: '+velocidade ao correr',        base: 60 },
  { id: 'stamina', n: 'Fôlego',         d: '+energia do dash',             base: 50 },
  { id: 'shield',  n: 'Escudo inicial', d: '+escudos a cada fase',         base: 90 },
  { id: 'pen',     n: 'Cercado top',    d: '+25% de renda por pessoa',     base: 120 }
];

const SAVE_KEY = 'roube-el-posei-v1';
const save = { coins: 0, level: 1, best: 1, stolen: 0, up: { speed: 0, stamina: 0, shield: 0, pen: 0 }, pen: [], veh: { scooter: false, moto: false }, equip: 'none' };
function loadSave() {
  try {
    const s = JSON.parse(localStorage.getItem(SAVE_KEY));
    if (s) { Object.assign(save, s); save.up = Object.assign({ speed: 0, stamina: 0, shield: 0, pen: 0 }, s.up || {}); save.veh = Object.assign({ scooter: false, moto: false }, s.veh || {}); if (!save.equip || (save.equip !== 'none' && !save.veh[save.equip])) save.equip = 'none'; }
  } catch (e) { /* sem storage: segue sem salvar */ }
}
function persist() { try { localStorage.setItem(SAVE_KEY, JSON.stringify(save)); } catch (e) {} }
function upCost(u) { return Math.round(u.base * Math.pow(1.7, save.up[u.id])); }

// ----- utilidades -----
const rand = (a, b) => a + Math.random() * (b - a);
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
function fmt(n) {
  n = Math.floor(n);
  if (n >= 1e6) return (n / 1e6).toFixed(1) + 'M';
  if (n >= 1e3) return (n / 1e3).toFixed(1) + 'k';
  return String(n);
}

// ----- som (WebAudio, sem arquivos) -----
let actx = null, soundOn = true;
function beep(freq, dur, type, vol, slide) {
  if (!soundOn) return;
  try {
    actx = actx || new (window.AudioContext || window.webkitAudioContext)();
    const o = actx.createOscillator(), g = actx.createGain();
    o.type = type || 'square';
    o.frequency.setValueAtTime(freq, actx.currentTime);
    if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(30, freq + slide), actx.currentTime + dur);
    g.gain.setValueAtTime(vol || 0.08, actx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.0001, actx.currentTime + dur);
    o.connect(g); g.connect(actx.destination);
    o.start(); o.stop(actx.currentTime + dur);
  } catch (e) {}
}
const SFX = {
  grab:  () => beep(500, 0.12, 'square', 0.07, 400),
  alarm: () => { beep(440, 0.15, 'sawtooth', 0.07); setTimeout(() => beep(330, 0.2, 'sawtooth', 0.07), 140); },
  coin:  () => { beep(880, 0.08, 'triangle', 0.09); setTimeout(() => beep(1320, 0.14, 'triangle', 0.09), 80); },
  hit:   () => beep(180, 0.3, 'sawtooth', 0.1, -120),
  power: () => beep(600, 0.25, 'triangle', 0.08, 700),
  level: () => [523, 659, 784, 1047].forEach((f, i) => setTimeout(() => beep(f, 0.16, 'triangle', 0.09), i * 110))
};
function vibrate(ms) { try { if (navigator.vibrate) navigator.vibrate(ms); } catch (e) {} }

// ----- controles: joystick virtual + botões + teclado -----
const input = { x: 0, y: 0, act: false, dash: false, jump: false };
let camYaw = 0;                       // ângulo da câmera orbital (3D)
const keys = {};
window.addEventListener('keydown', e => { if (e.target && e.target.tagName === 'INPUT') return; keys[e.key.toLowerCase()] = true; if (e.key === ' ') e.preventDefault(); });
window.addEventListener('keyup', e => { keys[e.key.toLowerCase()] = false; });

function setupInput() {
  const zone = document.getElementById('stickZone');
  const base = document.getElementById('stick');
  const knob = document.getElementById('knob');
  let pid = null, ox = 0, oy = 0;
  const R = 50;
  zone.addEventListener('pointerdown', e => {
    if (pid !== null) return;
    pid = e.pointerId; zone.setPointerCapture(pid);
    ox = e.clientX; oy = e.clientY;
    base.style.display = 'block';
    base.style.left = (ox - 60) + 'px'; base.style.top = (oy - 60) + 'px';
    knob.style.transform = 'translate(0px,0px)';
  });
  zone.addEventListener('pointermove', e => {
    if (e.pointerId !== pid) return;
    let dx = e.clientX - ox, dy = e.clientY - oy;
    const d = Math.hypot(dx, dy);
    if (d > R) { dx = dx / d * R; dy = dy / d * R; }
    input.x = dx / R; input.y = dy / R;
    knob.style.transform = 'translate(' + dx + 'px,' + dy + 'px)';
  });
  const end = e => {
    if (e.pointerId !== pid) return;
    pid = null; input.x = 0; input.y = 0; base.style.display = 'none';
  };
  zone.addEventListener('pointerup', end);
  zone.addEventListener('pointercancel', end);

  const hold = (id, key) => {
    const el = document.getElementById(id);
    const on = e => { e.preventDefault(); input[key] = true; el.classList.add('down'); vibrate(12); };
    const off = e => { e.preventDefault(); input[key] = false; el.classList.remove('down'); };
    el.addEventListener('pointerdown', on);
    el.addEventListener('pointerup', off);
    el.addEventListener('pointerleave', off);
    el.addEventListener('pointercancel', off);
  };
  // arrastar na direita da tela gira a câmera (como no Roblox)
  const cz = document.getElementById('camZone');
  let cp = null, lx = 0;
  cz.addEventListener('pointerdown', e => { if (cp !== null) return; cp = e.pointerId; lx = e.clientX; cz.setPointerCapture(cp); });
  cz.addEventListener('pointermove', e => { if (e.pointerId !== cp) return; camYaw -= (e.clientX - lx) * 0.009; lx = e.clientX; });
  const cend = e => { if (e.pointerId === cp) cp = null; };
  cz.addEventListener('pointerup', cend); cz.addEventListener('pointercancel', cend);
  hold('btnAct', 'act');
  hold('btnDash', 'dash');
  hold('btnJump', 'jump');
  document.addEventListener('contextmenu', e => e.preventDefault());
}
// entrada final combinando toque e teclado
function readInput() {
  let x = input.x, y = input.y;
  if (keys['a'] || keys['arrowleft']) x -= 1;
  if (keys['d'] || keys['arrowright']) x += 1;
  if (keys['w'] || keys['arrowup']) y -= 1;
  if (keys['s'] || keys['arrowdown']) y += 1;
  const m = Math.hypot(x, y);
  if (m > 1) { x /= m; y /= m; }
  // move relativo à câmera: cima = para onde a câmera olha
  const c = Math.cos(camYaw), s = Math.sin(camYaw);
  const rx = x * c + y * s, ry = -x * s + y * c;
  x = rx; y = ry;
  return { x, y, act: input.act || !!keys[' '] || !!keys['e'], dash: input.dash || !!keys['shift'], jump: input.jump || !!keys['j'] };
}
