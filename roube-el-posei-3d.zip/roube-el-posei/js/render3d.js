// ===== Roube el Posei 3D - renderizador (three.js) =====
import * as THREE from 'three';
import { makeBlocky, animateBlocky, makeLabel, makeBang } from './models.js';
import { S, X, Z, buildStatic, instanced } from './scene3d.js';

let renderer, scene, camera, clouds, hemi, sun, sky, fogCol;
let playerM, shieldBub, boostRing, arrow, blob;
const peopleMap = new Map(), guardMap = new Map(), pickMap = new Map();
let peopleGroup, guardGroup, pickGroup, mudGroup, treeGroup;
let mudRef = null, treesRef = null;
const penPool = [], partPool = [];
let penSig = '', playerAng = 0;
const camPos = new THREE.Vector3();
const dayCol = new THREE.Color(0x87ceeb), nightCol = new THREE.Color(0x0b1030), tmpCol = new THREE.Color();
let floatBox = null; const floatPool = [];
const vtmp = new THREE.Vector3();

function angLerp(a, b, k) {
  let d = b - a;
  while (d > Math.PI) d -= 2 * Math.PI;
  while (d < -Math.PI) d += 2 * Math.PI;
  return a + d * k;
}
function hex(c) { return String(c).slice(0, 7); }

function blobShadow(r) {
  const m = new THREE.Mesh(new THREE.CircleGeometry(r, 16), new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.28 }));
  m.rotation.x = -Math.PI / 2; m.position.y = 0.3; return m;
}
function glowRing(color) {
  const m = new THREE.Mesh(new THREE.RingGeometry(1.1, 1.6, 24), new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.7, side: THREE.DoubleSide }));
  m.rotation.x = -Math.PI / 2; m.position.y = 0.32; return m;
}

function init() {
  const canvas = document.getElementById('game');
  renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.75));
  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x87ceeb);
  scene.fog = new THREE.Fog(0x87ceeb, 55, 150);
  camera = new THREE.PerspectiveCamera(62, 1, 0.5, 400);
  hemi = new THREE.HemisphereLight(0xffffff, 0x88aa66, 1.0); scene.add(hemi);
  sun = new THREE.DirectionalLight(0xffffff, 0.9); sun.position.set(30, 60, 20); scene.add(sun);

  const st = buildStatic(scene); clouds = st.clouds;
  peopleGroup = new THREE.Group(); guardGroup = new THREE.Group(); pickGroup = new THREE.Group();
  mudGroup = new THREE.Group(); treeGroup = new THREE.Group();
  scene.add(peopleGroup, guardGroup, pickGroup, mudGroup, treeGroup);

  // jogador (ladrão de máscara)
  playerM = makeBlocky({ torso: '#ff9d00', legs: '#2a2a55', face: 'mask', mask: true });
  scene.add(playerM.group);
  blob = blobShadow(1.1); scene.add(blob);
  shieldBub = new THREE.Mesh(new THREE.SphereGeometry(2.4, 16, 12), new THREE.MeshBasicMaterial({ color: 0x7ad7ff, transparent: true, opacity: 0.25 }));
  scene.add(shieldBub);
  boostRing = glowRing(0xffe066); scene.add(boostRing);
  arrow = new THREE.Group();
  const cg = new THREE.ConeGeometry(0.6, 1.6, 8); cg.rotateX(Math.PI / 2);
  arrow.add(new THREE.Mesh(cg, new THREE.MeshBasicMaterial({ color: 0xffe066 })));
  scene.add(arrow);

  // pessoas no cercado (até 24)
  for (let i = 0; i < 24; i++) {
    const m = makeBlocky({ torso: 'hsl(' + ((i * 47) % 360) + ',70%,55%)', face: 'smile' });
    const ring = glowRing(0xffffff); m.group.add(ring);
    m.ring = ring; m.group.visible = false; scene.add(m.group); penPool.push(m);
  }
  // partículas
  for (let i = 0; i < 120; i++) {
    const p = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.28, 0.28), new THREE.MeshBasicMaterial({ color: 0xffffff }));
    p.visible = false; scene.add(p); partPool.push(p);
  }
  floatBox = document.getElementById('floaters');
  resize();
}

function resize() {
  if (!renderer) return;
  const w = window.innerWidth, h = window.innerHeight;
  renderer.setSize(w, h, false);
  renderer.domElement.style.width = w + 'px'; renderer.domElement.style.height = h + 'px';
  camera.aspect = w / h;
  camera.fov = w / h < 1 ? 72 : 55;
  camera.updateProjectionMatrix();
}

function syncMap(list, map, create, parent, visibleFn) {
  for (const it of list) {
    let o = map.get(it);
    if (!o) { o = create(it); map.set(it, o); parent.add(o.group || o); }
    if (visibleFn) visibleFn(it, o);
  }
  if (map.size !== list.length || list.length && !map.has(list[0])) {
    for (const [k, o] of map) {
      if (!list.includes(k)) { parent.remove(o.group || o); map.delete(k); }
    }
  }
}

function rebuildStatics() {
  if (mudRef !== G.mud) {
    mudRef = G.mud;
    while (mudGroup.children.length) mudGroup.remove(mudGroup.children[0]);
    for (const m of G.mud) {
      const c = new THREE.Mesh(new THREE.CircleGeometry(m.r * S, 20), new THREE.MeshBasicMaterial({ color: 0x6b4a2b }));
      c.rotation.x = -Math.PI / 2; c.position.set(X(m.x), 0.33, Z(m.y)); c.scale.set(1, 0.7, 1);
      mudGroup.add(c);
    }
  }
  if (treesRef !== G.trees) {
    treesRef = G.trees;
    while (treeGroup.children.length) treeGroup.remove(treeGroup.children[0]);
    const trunks = G.trees.map(t => ({ x: X(t.x), y: 1.3 * t.s, z: Z(t.y), s: t.s }));
    const leaf1 = G.trees.map(t => ({ x: X(t.x), y: 3.8 * t.s, z: Z(t.y), s: t.s }));
    const leaf2 = G.trees.map(t => ({ x: X(t.x), y: 5.8 * t.s, z: Z(t.y), s: t.s }));
    treeGroup.add(instanced(new THREE.BoxGeometry(0.7, 2.6, 0.7), new THREE.MeshLambertMaterial({ color: 0x6b4a2b }), trunks));
    treeGroup.add(instanced(new THREE.BoxGeometry(3.4, 2.6, 3.4), new THREE.MeshLambertMaterial({ color: 0x2f9a45 }), leaf1));
    treeGroup.add(instanced(new THREE.BoxGeometry(2.2, 2.0, 2.2), new THREE.MeshLambertMaterial({ color: 0x3cb857 }), leaf2));
  }
}

function createPerson(per) {
  const m = makeBlocky({ torso: 'hsl(' + per.hue + ',70%,55%)', face: 'smile' });
  const rc = RARITIES[per.rar];
  m.ring = glowRing(rc.c); m.ring.visible = per.rar > 0; m.group.add(m.ring);
  m.label = makeLabel(per.name + ' · ' + rc.n, rc.c); m.label.position.y = 5.2; m.group.add(m.label);
  m.blob = blobShadow(1.1); m.group.add(m.blob);
  m.group.rotation.y = (per.id % 2 ? 0.5 : -0.5);
  return m;
}
function createGuard() {
  const m = makeBlocky({ torso: '#3b5ee2', legs: '#1b2b6b', face: 'angry', cap: '#111111' });
  m.bang = makeBang(); m.bang.position.y = 5.0; m.bang.visible = false; m.group.add(m.bang);
  m.blob = blobShadow(1.1); m.group.add(m.blob);
  return m;
}
function createPickup(it) {
  let mesh;
  if (it.kind === 'boost') mesh = new THREE.Mesh(new THREE.OctahedronGeometry(0.9), new THREE.MeshLambertMaterial({ color: 0xffe066, emissive: 0xaa8800 }));
  else if (it.kind === 'shield') mesh = new THREE.Mesh(new THREE.SphereGeometry(0.85, 14, 10), new THREE.MeshLambertMaterial({ color: 0x4aa8ff, emissive: 0x113355 }));
  else { mesh = new THREE.Mesh(new THREE.CylinderGeometry(0.8, 0.8, 0.25, 16), new THREE.MeshLambertMaterial({ color: 0xffc400, emissive: 0x665000 })); mesh.rotation.z = Math.PI / 2; }
  const g = new THREE.Group(); g.add(mesh); g.userData.mesh = mesh;
  return g;
}

function floaters(t) {
  const list = G.texts;
  while (floatPool.length < list.length) {
    const d = document.createElement('div'); d.className = 'float'; floatBox.appendChild(d); floatPool.push(d);
  }
  for (let i = 0; i < floatPool.length; i++) {
    const d = floatPool[i], f = list[i];
    if (!f) { d.style.display = 'none'; continue; }
    vtmp.set(X(f.x), 3.5 + (1.2 - f.life) * 3, Z(f.y)); vtmp.project(camera);
    d.style.display = 'block';
    d.style.left = ((vtmp.x * 0.5 + 0.5) * window.innerWidth) + 'px';
    d.style.top = ((-vtmp.y * 0.5 + 0.5) * window.innerHeight) + 'px';
    d.style.opacity = Math.min(1, f.life); d.style.color = f.c; d.textContent = f.t;
  }
}

function draw() {
  if (!renderer) return;
  const t = G.time, p = G.p;
  rebuildStatics();

  // pessoas da fase
  syncMap(G.people, peopleMap, createPerson, peopleGroup, (per, m) => {
    const carried = G.carrying === per;
    m.group.visible = !per.taken || carried;
    if (carried) {
      m.group.position.set(X(p.x), 2.7, Z(p.y)); m.group.rotation.y = playerAng; m.group.scale.setScalar(0.8);
      animateBlocky(m, t, 0, true); m.ring.visible = false; m.label.visible = false; m.blob.visible = false;
    } else {
      m.group.position.set(X(per.x), 0.3, Z(per.y)); m.group.scale.setScalar(1);
      animateBlocky(m, t, 0, false); m.group.position.y = 0.3 + Math.abs(Math.sin(t * 2 + per.id)) * 0.12;
      m.ring.visible = per.rar > 0; m.label.visible = true; m.blob.visible = true;
    }
  });
  // guardas
  syncMap(G.guards, guardMap, createGuard, guardGroup, (g, m) => {
    const sp = Math.hypot(g.vx, g.vy);
    m.group.position.set(X(g.x), 0.3, Z(g.y));
    if (sp > 5 && g.stun <= 0) m.group.rotation.y = angLerp(m.group.rotation.y, Math.atan2(g.vx, g.vy), 0.2);
    animateBlocky(m, t, sp / 120, false);
    const chase = g.state === 'chase';
    m.mTorso.color.set(g.stun > 0 ? 0x999999 : chase ? 0xe23b3b : 0x3b5ee2);
    m.bang.visible = chase && g.stun <= 0;
    if (g.stun > 0) m.group.rotation.y += 0.25;
  });
  // itens
  syncMap(G.pickups, pickMap, createPickup, pickGroup, (it, o) => {
    o.position.set(X(it.x), 1.6 + Math.sin(it.t * 3) * 0.35, Z(it.y));
    o.userData.mesh.rotation.y += 0.04;
  });

  // pessoas garantidas passeando no cercado
  const n = Math.min(24, save.pen.length);
  const sig = save.pen.slice(0, 24).join(',');
  for (let i = 0; i < 24; i++) {
    const m = penPool[i];
    m.group.visible = i < n;
    if (i >= n) continue;
    const col = i % 8, row = (i / 8) | 0;
    const x = 300 + col * 110 + Math.sin(t * 0.8 + i) * 25, y = CFG.penTop + 130 + row * 90 + Math.cos(t * 0.7 + i) * 15;
    m.group.position.set(X(x), 0.5, Z(y));
    m.group.rotation.y = Math.sin(t * 0.8 + i) > 0 ? 1.2 : -1.2;
    animateBlocky(m, t, 0.35, false);
    if (sig !== penSig) { m.ring.material.color.set(RARITIES[save.pen[i]].c); m.ring.visible = save.pen[i] > 0; }
  }
  penSig = sig;

  // jogador
  const sp = Math.hypot(p.vx, p.vy);
  if (sp > 8) playerAng = angLerp(playerAng, Math.atan2(p.vx, p.vy), 0.25);
  playerM.group.position.set(X(p.x), 0.3, Z(p.y));
  playerM.group.rotation.y = playerAng;
  playerM.group.visible = p.stun > 0 ? Math.floor(t * 14) % 2 === 0 : true;
  animateBlocky(playerM, t, sp / 150, !!G.carrying);
  blob.position.set(X(p.x), 0.31, Z(p.y));
  shieldBub.visible = p.shield > 0; shieldBub.position.set(X(p.x), 1.8, Z(p.y));
  boostRing.visible = p.boost > 0; boostRing.position.set(X(p.x), 0.34, Z(p.y)); boostRing.rotation.z = t * 4;
  arrow.visible = !!G.carrying;
  if (G.carrying) {
    arrow.position.set(X(p.x), 6.3 + Math.sin(t * 6) * 0.2, Z(p.y));
    arrow.rotation.y = Math.atan2(X(CFG.laneX) - X(p.x), Z(CFG.finishY) - Z(p.y));
  }

  // partículas
  for (let i = 0; i < partPool.length; i++) {
    const q = G.parts[i], m = partPool[i];
    if (!q) { m.visible = false; continue; }
    m.visible = true; m.position.set(X(q.x), 0.8 + Math.max(0, q.life) * 2.5, Z(q.y));
    m.material.color.set(hex(q.c));
  }

  // dia / noite
  const cyc = (Math.sin(t / 40) + 1) / 2, k = cyc > 0.5 ? (cyc - 0.5) * 2 : 0;
  tmpCol.copy(dayCol).lerp(nightCol, k * 0.85);
  scene.background.copy(tmpCol); scene.fog.color.copy(tmpCol);
  hemi.intensity = 1.0 - k * 0.6; sun.intensity = 0.9 - k * 0.6;
  clouds.position.x = (t * 0.6) % 40 - 20;

  // câmera orbital (arraste na direita gira)
  const D = 15, H = 9.5;
  const tx = X(p.x), tz = Z(p.y);
  const wantX = tx + Math.sin(camYaw) * D, wantZ = tz + Math.cos(camYaw) * D;
  if (camPos.lengthSq() === 0) camPos.set(wantX, H, wantZ);
  camPos.x += (wantX - camPos.x) * 0.18; camPos.z += (wantZ - camPos.z) * 0.18; camPos.y = H;
  const sh = G.shake > 0 ? 0.35 : 0;
  camera.position.set(camPos.x + (Math.random() - 0.5) * sh, camPos.y, camPos.z + (Math.random() - 0.5) * sh);
  camera.lookAt(tx, 2.2, tz);

  floaters(t);
  renderer.render(scene, camera);
}

window.R3D = { init, resize, draw };
window.addEventListener('resize', resize);
