// ===== Modelos 3D estilo Roblox (blocos) =====
import * as THREE from 'three';

const GEO = {
  leg: new THREE.BoxGeometry(0.7, 1.0, 0.7),
  torso: new THREE.BoxGeometry(1.6, 1.4, 0.8),
  arm: new THREE.BoxGeometry(0.6, 1.3, 0.6),
  head: new THREE.BoxGeometry(1.2, 1.2, 1.2),
  cap: new THREE.BoxGeometry(1.35, 0.4, 1.35),
  capBill: new THREE.BoxGeometry(1.0, 0.12, 0.6),
  mask: new THREE.BoxGeometry(1.26, 0.32, 1.26)
};
const faceCache = {};
function faceTexture(kind, skin) {
  const key = kind + skin;
  if (faceCache[key]) return faceCache[key];
  const c = document.createElement('canvas'); c.width = c.height = 64;
  const g = c.getContext('2d');
  g.fillStyle = skin; g.fillRect(0, 0, 64, 64);
  g.fillStyle = '#111';
  if (kind === 'angry') {
    g.fillRect(14, 24, 12, 8); g.fillRect(38, 24, 12, 8);
    g.fillRect(12, 16, 16, 5); g.fillRect(36, 16, 16, 5);
    g.fillRect(22, 44, 20, 5);
  } else if (kind === 'mask') {
    g.fillStyle = '#fff'; g.fillRect(14, 22, 14, 10); g.fillRect(36, 22, 14, 10);
    g.fillStyle = '#111'; g.fillRect(19, 24, 6, 7); g.fillRect(41, 24, 6, 7);
    g.fillRect(22, 44, 20, 4);
  } else {
    g.fillRect(16, 22, 8, 10); g.fillRect(40, 22, 8, 10);
    g.fillRect(18, 42, 28, 4); g.fillRect(14, 38, 5, 5); g.fillRect(45, 38, 5, 5);
  }
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  faceCache[key] = t;
  return t;
}

// opts: {torso, legs, skin, face, cap, mask}
export function makeBlocky(o) {
  const skin = o.skin || '#ffd9b3';
  const group = new THREE.Group();
  const model = new THREE.Group();
  model.scale.setScalar(0.7);
  group.add(model);
  const mTorso = new THREE.MeshLambertMaterial({ color: o.torso });
  const mLegs = new THREE.MeshLambertMaterial({ color: o.legs || '#2a2a55' });
  const mSkin = new THREE.MeshLambertMaterial({ color: skin });

  const pivot = (mesh, x, y, oy) => {
    const p = new THREE.Group(); p.position.set(x, y, 0);
    mesh.position.y = oy; p.add(mesh); model.add(p); return p;
  };
  const legL = pivot(new THREE.Mesh(GEO.leg, mLegs), -0.4, 1.0, -0.5);
  const legR = pivot(new THREE.Mesh(GEO.leg, mLegs), 0.4, 1.0, -0.5);
  const torso = new THREE.Mesh(GEO.torso, mTorso); torso.position.y = 1.7; model.add(torso);
  const armL = pivot(new THREE.Mesh(GEO.arm, mSkin), -1.1, 2.3, -0.55);
  const armR = pivot(new THREE.Mesh(GEO.arm, mSkin), 1.1, 2.3, -0.55);
  const faceMat = new THREE.MeshLambertMaterial({ map: faceTexture(o.face || 'smile', skin) });
  const head = new THREE.Mesh(GEO.head, [mSkin, mSkin, mSkin, mSkin, faceMat, mSkin]);
  head.position.y = 3.0; model.add(head);
  if (o.cap) {
    const mc = new THREE.MeshLambertMaterial({ color: o.cap });
    const cap = new THREE.Mesh(GEO.cap, mc); cap.position.y = 3.7; model.add(cap);
    const bill = new THREE.Mesh(GEO.capBill, mc); bill.position.set(0, 3.52, 0.8); model.add(bill);
  }
  if (o.mask) {
    const mm = new THREE.Mesh(GEO.mask, new THREE.MeshLambertMaterial({ color: 0x111111 }));
    mm.position.y = 3.25; model.add(mm);
  }
  return { group, model, legL, legR, armL, armR, mTorso, mSkin, faceMat };
}

// balanço de braços/pernas; up = braços levantados (carregando)
export function animateBlocky(m, t, speed, up) {
  const sw = Math.sin(t * 11) * Math.min(1, speed) * 0.9;
  m.legL.rotation.x = sw; m.legR.rotation.x = -sw;
  if (up) { m.armL.rotation.x = -3.0; m.armR.rotation.x = -3.0; }
  else { m.armL.rotation.x = -sw; m.armR.rotation.x = sw; }
}

export function makeLabel(text, color) {
  const c = document.createElement('canvas'); c.width = 256; c.height = 64;
  const g = c.getContext('2d');
  g.fillStyle = 'rgba(0,0,0,0.6)';
  g.beginPath(); g.roundRect ? g.roundRect(4, 8, 248, 48, 16) : g.rect(4, 8, 248, 48); g.fill();
  g.fillStyle = color; g.font = 'bold 28px sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle';
  g.fillText(text, 128, 33);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
  const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: t, transparent: true, depthTest: false }));
  s.scale.set(5, 1.25, 1); s.renderOrder = 10;
  return s;
}

export function makeBang() {
  const c = document.createElement('canvas'); c.width = c.height = 64;
  const g = c.getContext('2d');
  g.fillStyle = '#e23b3b'; g.beginPath(); g.arc(32, 32, 28, 0, 6.28); g.fill();
  g.fillStyle = '#fff'; g.font = 'bold 44px sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle';
  g.fillText('!', 32, 35);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
  const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: t, transparent: true, depthTest: false }));
  s.scale.set(1.5, 1.5, 1); s.renderOrder = 11;
  return s;
}

export function textPlane(text, w, h, bg, fg, font) {
  const c = document.createElement('canvas'); c.width = 512; c.height = Math.round(512 * h / w);
  const g = c.getContext('2d');
  g.fillStyle = bg; g.fillRect(0, 0, c.width, c.height);
  g.fillStyle = fg; g.font = font || 'bold 64px sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle';
  g.fillText(text, c.width / 2, c.height / 2 + 4);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
  return new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshBasicMaterial({ map: t }));
}

export function checkerTexture(cols, rows) {
  const c = document.createElement('canvas'); c.width = cols * 32; c.height = rows * 32;
  const g = c.getContext('2d');
  for (let i = 0; i < cols; i++) for (let j = 0; j < rows; j++) {
    g.fillStyle = (i + j) % 2 ? '#111' : '#fff'; g.fillRect(i * 32, j * 32, 32, 32);
  }
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
  return t;
}
