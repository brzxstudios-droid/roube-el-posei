'use strict';
// ===== Roube el Posei - simulação por frame =====
function update(dt) {
  G.time += dt;
  const p = G.p, inp = readInput();
  if (G.bannerT > 0) G.bannerT -= dt;
  if (G.shake > 0) G.shake -= dt;

  // ----- jogador -----
  if (p.stun > 0) p.stun -= dt;
  let spd = playerSpeed();
  if (G.carrying) spd *= 0.8 - RARITIES[G.carrying.rar].v / 1000 * 0.05; // pessoas valiosas pesam mais
  if (p.boost > 0) { p.boost -= dt; spd *= 1.35; }
  for (const m of G.mud) if (Math.hypot(p.x - m.x, p.y - m.y) < m.r) { spd *= 0.55; break; }
  const moving = Math.hypot(inp.x, inp.y) > 0.1;
  p.dashing = inp.dash && moving && p.stamina > 0 && p.stun <= 0;
  if (p.dashing) { spd *= 1.6; p.stamina = Math.max(0, p.stamina - 35 * dt); if (Math.random() < 0.4) addPart(p.x, p.y + 10, '#ffffff66', 1, 40); }
  else p.stamina = Math.min(maxStamina(), p.stamina + 18 * dt);
  if (p.stun <= 0) {
    p.vx += (inp.x * spd - p.vx) * Math.min(1, dt * 12);
    p.vy += (inp.y * spd - p.vy) * Math.min(1, dt * 12);
  } else { p.vx *= 0.8; p.vy *= 0.8; }
  p.x += p.vx * dt; p.y += p.vy * dt;
  if (Math.abs(inp.x) > 0.1) p.face = inp.x > 0 ? 1 : -1;
  p.steps += Math.hypot(p.vx, p.vy) * dt * 0.05;
  clampToIsland(p);

  // ----- roubar (segura o botão perto de uma pessoa) -----
  if (!G.carrying && p.stun <= 0) {
    let near = null, nd = 70;
    for (const per of G.people) {
      if (per.taken) continue;
      const d = dist(p, per);
      if (d < nd) { nd = d; near = per; }
    }
    if (near && inp.act) {
      if (G.grabbing !== near) { G.grabbing = near; G.grabT = 0; }
      G.grabT += dt;
      // guardas percebem o roubo quando ele está quase completo
      if (G.grabT > 0.35) for (const g of G.guards) if (g.home === near && g.state === 'patrol' && dist(g, p) < 160) g.state = 'chase';
      if (G.grabT >= 0.55) {
        G.carrying = near; near.taken = true; G.grabbing = null;
        SFX.grab(); SFX.alarm(); vibrate(60); G.alarm = 1;
        addPart(near.x, near.y, RARITIES[near.rar].c, 20);
        banner('CORRE! Leva até a linha de chegada!');
        // guardas levam um susto (0,8s) e depois perseguem: dá tempo de arrancar
        for (const g of G.guards) if (g.home === near) { g.state = 'chase'; g.stun = 0.8; }
      }
    } else { G.grabbing = null; G.grabT = 0; }
  } else { G.grabbing = null; G.grabT = 0; }

  if (G.carrying) {
    G.carrying.x = p.x - p.face * 18; G.carrying.y = p.y - 6;
    if (p.y > CFG.finishY && G.carrying) secure();
  }

  // ----- guardas -----
  const gs = guardSpeed();
  for (const g of G.guards) {
    if (g.stun > 0) { g.stun -= dt; continue; }
    const per = g.home;
    let tx, ty, sp = gs * 0.45;
    if (g.state === 'patrol') {
      g.ang += dt * (0.8 + save.level * 0.04);
      tx = per.hx + Math.cos(g.ang) * g.orb; ty = per.hy + Math.sin(g.ang) * g.orb;
      // furtivo: só nota de bem perto; correr faz barulho e alerta de mais longe
      const dp = dist(g, p), notice = p.dashing ? 190 : 62;
      if (!G.carrying && dp < notice && !inSafe(p) && p.stun <= 0) g.state = 'chase';
    } else if (g.state === 'chase') {
      if (inSafe(p) || p.stun > 0 || (!G.carrying && dist(g, p) > 340)) { g.state = 'return'; }
      tx = p.x; ty = p.y; sp = gs;
      // quem não tem a pessoa roubada persegue um pouco mais devagar
      if (G.carrying !== per) sp *= 0.85;
    } else { // return
      tx = per.hx; ty = per.hy; sp = gs * 0.7;
      if (Math.hypot(g.x - tx, g.y - ty) < 80) g.state = 'patrol';
    }
    const dx = tx - g.x, dy = ty - g.y, d = Math.hypot(dx, dy) || 1;
    g.vx = dx / d * sp; g.vy = dy / d * sp;
    g.x += g.vx * dt; g.y += g.vy * dt;
    if (g.y > CFG.finishY - 10) g.y = CFG.finishY - 10;   // cercado é zona segura
    clampToIsland(g);
    if (g.state === 'chase' && dist(g, p) < g.r + p.r - 2) caught(g);
  }

  // ----- itens -----
  for (let i = G.pickups.length - 1; i >= 0; i--) {
    const it = G.pickups[i]; it.t += dt;
    if (Math.hypot(it.x - p.x, it.y - p.y) < 30) {
      if (it.kind === 'boost') { p.boost = 6; addText(p.x, p.y - 30, 'Turbo!', '#ffe066'); }
      else if (it.kind === 'shield') { p.shield = Math.min(6, p.shield + 1); addText(p.x, p.y - 30, '+Escudo', '#7ad7ff'); }
      else { const v = 15 + save.level * 8; save.coins += v; addText(p.x, p.y - 30, '+' + v + ' 🪙', '#ffe066'); persist(); }
      SFX.power(); addPart(it.x, it.y, '#fff', 14); G.pickups.splice(i, 1);
    }
  }

  // ----- renda passiva do cercado -----
  save.coins += incomePerSec() * dt;
  if (Math.floor(G.time) % 10 === 0 && Math.floor(G.time - dt) % 10 !== 0) persist();

  // ----- partículas / textos -----
  for (let i = G.parts.length - 1; i >= 0; i--) {
    const q = G.parts[i]; q.life -= dt; q.x += q.vx * dt; q.y += q.vy * dt; q.vx *= 0.94; q.vy *= 0.94;
    if (q.life <= 0) G.parts.splice(i, 1);
  }
  for (let i = G.texts.length - 1; i >= 0; i--) {
    const t = G.texts[i]; t.life -= dt; t.y -= 30 * dt; if (t.life <= 0) G.texts.splice(i, 1);
  }
}

// mantém dentro da ilha (retângulo arredondado)
function clampToIsland(o) {
  o.x = clamp(o.x, 140, MAP.w - 140);
  o.y = clamp(o.y, 200, MAP.h - 140);
}
