'use strict';
// ===== Roube el Posei - lógica do mundo =====
const G = {
  p: null, people: [], guards: [], pickups: [], mud: [], trees: [], parts: [], texts: [],
  carrying: null, grabbing: null, grabT: 0, banner: '', bannerT: 0,
  shake: 0, time: 0, running: false, alarm: 0, stolenThisLevel: 0, totalThisLevel: 0
};

function guardSpeed() { return Math.min(235, 125 + save.level * 9); }
function playerSpeed() { return 205 + save.up.speed * 18; }
function maxStamina() { return 100 + save.up.stamina * 25; }
function incomePerSec() {
  let s = 0;
  for (const r of save.pen) s += RARITIES[r].v * 0.04;
  return s * (1 + 0.25 * save.up.pen);
}

function newPlayer() {
  return {
    x: CFG.laneX, y: CFG.penTop + 120, r: 16, vx: 0, vy: 0, face: 1,
    stamina: maxStamina(), stun: 0, shield: Math.min(CFG.maxUp, save.up.shield),
    boost: 0, dashing: false, steps: 0
  };
}

function addPart(x, y, color, n, spd) {
  for (let i = 0; i < n; i++) {
    const a = Math.random() * 6.28, s = rand(20, spd || 120);
    G.parts.push({ x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s, life: rand(0.3, 0.8), c: color, r: rand(2, 4) });
  }
}
function addText(x, y, t, c) { G.texts.push({ x, y, t, c: c || '#fff', life: 1.2 }); }
function banner(t) { G.banner = t; G.bannerT = 2.2; }

function buildLevel() {
  const lvl = save.level;
  G.people = []; G.guards = []; G.pickups = []; G.mud = []; G.trees = [];
  G.carrying = null; G.grabbing = null; G.alarm = 0; G.stolenThisLevel = 0;
  G.p = newPlayer();
  const count = Math.min(10, 3 + lvl);
  G.totalThisLevel = count;
  for (let i = 0; i < count; i++) {
    const t = count === 1 ? 1 : i / (count - 1);           // 0 perto do cercado, 1 longe
    const y = CFG.firstY - t * (CFG.firstY - CFG.lastY) + rand(-40, 40);
    const side = i % 3 === 0 ? 0 : (i % 3 === 1 ? -1 : 1);
    const x = CFG.laneX + side * (CFG.laneW / 2 + 70) + rand(-20, 20);
    // raridade cresce com a distância e com a fase
    const roll = Math.random() * 0.6 + t * 0.9 + lvl * 0.05;
    let ri = roll < 0.55 ? 0 : roll < 0.95 ? 1 : roll < 1.3 ? 2 : roll < 1.6 ? 3 : 4;
    ri = Math.min(ri, 4);
    const per = {
      x, y, hx: x, hy: y, r: 18, rar: ri, name: NAMES[(Math.random() * NAMES.length) | 0],
      hue: (Math.random() * 360) | 0, taken: false, id: i
    };
    G.people.push(per);
    const gn = Math.min(5, 1 + Math.floor(lvl / 3) + (ri >= 3 ? 1 : 0) + (ri === 4 ? 1 : 0));
    for (let g = 0; g < gn; g++) {
      G.guards.push({
        x: x + rand(-60, 60), y: y + rand(-60, 60), r: 17, home: per, ang: Math.random() * 6.28,
        orb: rand(60, 110), state: 'patrol', stun: 0, vx: 0, vy: 0
      });
    }
  }
  // power-ups pela reta
  const kinds = ['boost', 'shield', 'coin'];
  for (let i = 0; i < 4 + Math.min(lvl, 4); i++) {
    G.pickups.push({
      x: CFG.laneX + rand(-CFG.laneW / 2 + 20, CFG.laneW / 2 - 20),
      y: rand(CFG.lastY + 150, CFG.firstY - 80), kind: kinds[(Math.random() * 3) | 0], t: Math.random() * 6
    });
  }
  // poças de lama na reta (deixam lento)
  for (let i = 0; i < 3 + Math.min(lvl, 5); i++) {
    G.mud.push({ x: CFG.laneX + rand(-CFG.laneW / 2 + 30, CFG.laneW / 2 - 30), y: rand(CFG.lastY + 100, CFG.firstY - 60), r: rand(34, 52) });
  }
  // árvores decorativas (fora da reta)
  let seed = 7;
  const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
  for (let i = 0; i < 70; i++) {
    const x = 150 + rnd() * (MAP.w - 300), y = 220 + rnd() * (CFG.penTop - 300);
    if (Math.abs(x - CFG.laneX) < CFG.laneW / 2 + 130) continue;
    G.trees.push({ x, y, s: 0.8 + rnd() * 0.7 });
  }
  banner('Fase ' + lvl + '  ·  ' + count + ' pessoas');
}

// área segura: dentro do cercado os guardas não entram
function inSafe(o) { return o.y > CFG.finishY; }

function dropCarried(msg) {
  if (!G.carrying) return;
  const per = G.carrying;
  per.taken = false; per.x = per.hx; per.y = per.hy;
  G.carrying = null;
  for (const g of G.guards) if (g.home === per) g.state = 'return';
  if (msg) addText(G.p.x, G.p.y - 30, msg, '#ff7a7a');
}

function secure() {
  const per = G.carrying;
  const val = RARITIES[per.rar].v * (1 + 0.25 * save.up.pen);
  save.coins += val; save.stolen++;
  save.pen.push(per.rar); if (save.pen.length > 80) save.pen.shift();
  per.taken = true; per.done = true;
  G.carrying = null; G.stolenThisLevel++;
  for (const g of G.guards) if (g.home === per) g.state = 'return';
  addText(G.p.x, G.p.y - 40, '+' + fmt(val) + ' 🪙', '#ffe066');
  addPart(G.p.x, G.p.y, RARITIES[per.rar].c, 30, 200);
  SFX.coin(); vibrate(40);
  banner('Garantido! ' + RARITIES[per.rar].n);
  persist();
  if (G.stolenThisLevel >= G.totalThisLevel) {
    save.level++; save.best = Math.max(save.best, save.level);
    persist(); SFX.level();
    setTimeout(() => { buildLevel(); banner('Fase ' + save.level + '!'); }, 1400);
    banner('FASE COMPLETA! 🎉');
  }
}

function caught(g) {
  const p = G.p;
  if (p.stun > 0) return;
  if (p.shield > 0) {
    p.shield--; g.stun = 2; p.stun = 0.6;
    const a = Math.atan2(g.y - p.y, g.x - p.x);
    g.x += Math.cos(a) * 80; g.y += Math.sin(a) * 80;
    addText(p.x, p.y - 30, 'Escudo!', '#7ad7ff'); SFX.power(); addPart(p.x, p.y, '#7ad7ff', 18);
    return;
  }
  SFX.hit(); vibrate(200); G.shake = 0.5;
  dropCarried('Pego!');
  p.x = CFG.laneX; p.y = CFG.penTop + 120; p.stun = 1.2; p.stamina = maxStamina() * 0.5;
  for (const gg of G.guards) { gg.state = 'return'; }
  addPart(p.x, p.y, '#ff5555', 24);
}
