// ===== Cenário 3D estático (ilha, cercado, reta, arco de chegada) =====
import * as THREE from 'three';
import { textPlane, checkerTexture } from './models.js';

export const S = 0.05;                    // 1 unidade 3D = 20 px do jogo
export const X = x => x * S;
export const Z = y => y * S;

function box(w, h, d, color, x, y, z, parent) {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), new THREE.MeshLambertMaterial({ color }));
  m.position.set(x, y, z); parent.add(m); return m;
}
// retângulo em coordenadas do jogo (px): cria caixa com topo em yTop
function slab(x0, y0, x1, y1, yTop, thick, color, parent) {
  return box((x1 - x0) * S, thick, (y1 - y0) * S, color, X((x0 + x1) / 2), yTop - thick / 2, Z((y0 + y1) / 2), parent);
}

export function instanced(geo, mat, list) {
  const im = new THREE.InstancedMesh(geo, mat, Math.max(1, list.length));
  const d = new THREE.Object3D();
  list.forEach((it, i) => {
    d.position.set(it.x, it.y, it.z); d.scale.setScalar(it.s || 1); d.rotation.set(0, it.r || 0, 0);
    d.updateMatrix(); im.setMatrixAt(i, d.matrix);
  });
  im.count = list.length; im.instanceMatrix.needsUpdate = true;
  return im;
}

export function buildStatic(scene) {
  const g = new THREE.Group(); scene.add(g);
  // mar
  const sea = new THREE.Mesh(new THREE.PlaneGeometry(900, 900), new THREE.MeshLambertMaterial({ color: 0x1f8fd1 }));
  sea.rotation.x = -Math.PI / 2; sea.position.set(X(700), -0.7, Z(1500)); g.add(sea);
  // ilha: areia, grama, cercado, reta
  slab(60, 120, 1340, 2940, 0, 1.2, 0xf0d78c, g);
  slab(110, 170, 1290, 2890, 0.12, 0.4, 0x58c26a, g);
  slab(200, CFG.penTop, 1200, CFG.penBottom, 0.24, 0.3, 0x8bd37a, g);
  slab(CFG.laneX - CFG.laneW / 2, 200, CFG.laneX + CFG.laneW / 2, CFG.penTop, 0.26, 0.3, 0xc9a56b, g);
  // faixa tracejada da reta
  for (let y = 240; y < CFG.penTop - 40; y += 90) box(0.25, 0.05, 2.0, 0xa98450, X(CFG.laneX), 0.29, Z(y), g);

  // linha de chegada (xadrez no chão) + arco
  const fl = new THREE.Mesh(new THREE.PlaneGeometry((CFG.laneW + 80) * S, 2.2), new THREE.MeshBasicMaterial({ map: checkerTexture(14, 2) }));
  fl.rotation.x = -Math.PI / 2; fl.position.set(X(CFG.laneX), 0.32, Z(CFG.finishY)); g.add(fl);
  const ax = (CFG.laneW / 2 + 45) * S;
  box(0.9, 9, 0.9, 0xffffff, X(CFG.laneX) - ax, 4.5, Z(CFG.finishY), g);
  box(0.9, 9, 0.9, 0xffffff, X(CFG.laneX) + ax, 4.5, Z(CFG.finishY), g);
  const ban = textPlane('🏁 CHEGADA 🏁', ax * 2, 2.6, '#e23b3b', '#ffffff');
  ban.position.set(X(CFG.laneX), 8.2, Z(CFG.finishY)); g.add(ban);
  const ban2 = ban.clone(); ban2.rotation.y = Math.PI; ban2.position.z += 0.05; g.add(ban2);

  // cerca do cercado (postes instanciados + travessas)
  const posts = [];
  const px = (x, y) => posts.push({ x: X(x), y: 0.9, z: Z(y) });
  const gapL = CFG.laneX - 110, gapR = CFG.laneX + 110;
  for (let x = 200; x <= 1200; x += 34) { if (x > gapL && x < gapR) continue; px(x, CFG.penTop); px(x, CFG.penBottom); }
  for (let y = CFG.penTop + 34; y < CFG.penBottom; y += 34) { px(200, y); px(1200, y); }
  g.add(instanced(new THREE.BoxGeometry(0.35, 1.8, 0.35), new THREE.MeshLambertMaterial({ color: 0x8a5a2b }), posts));
  const railMat = 0x9b6a35;
  box((gapL - 200) * S, 0.2, 0.2, railMat, X((200 + gapL) / 2), 1.3, Z(CFG.penTop), g);
  box((1200 - gapR) * S, 0.2, 0.2, railMat, X((gapR + 1200) / 2), 1.3, Z(CFG.penTop), g);
  box(1000 * S, 0.2, 0.2, railMat, X(700), 1.3, Z(CFG.penBottom), g);
  box(0.2, 0.2, (CFG.penBottom - CFG.penTop) * S, railMat, X(200), 1.3, Z((CFG.penTop + CFG.penBottom) / 2), g);
  box(0.2, 0.2, (CFG.penBottom - CFG.penTop) * S, railMat, X(1200), 1.3, Z((CFG.penTop + CFG.penBottom) / 2), g);
  // placa do cercado
  const sign = textPlane('SEU CERCADO', 14, 3, '#2e7d32', '#ffffff');
  sign.position.set(X(700), 4.5, Z(CFG.penBottom) - 0.3); g.add(sign);
  box(0.3, 4.5, 0.3, 0x6b4a2b, X(700) - 6.5, 2.25, Z(CFG.penBottom) - 0.5, g);
  box(0.3, 4.5, 0.3, 0x6b4a2b, X(700) + 6.5, 2.25, Z(CFG.penBottom) - 0.5, g);

  // nuvens de blocos
  const clouds = new THREE.Group(); g.add(clouds);
  const cm = new THREE.MeshLambertMaterial({ color: 0xffffff, transparent: true, opacity: 0.9 });
  for (let i = 0; i < 14; i++) {
    const c = new THREE.Group();
    for (let k = 0; k < 3; k++) {
      const b = new THREE.Mesh(new THREE.BoxGeometry(6 + k * 2, 2, 4), cm); b.position.set(k * 4 - 4, (k % 2) * 0.5, 0); c.add(b);
    }
    c.position.set(-40 + (i * 53) % 190, 38 + (i % 4) * 4, -20 + ((i * 37) % 190)); clouds.add(c);
  }
  return { clouds };
}
