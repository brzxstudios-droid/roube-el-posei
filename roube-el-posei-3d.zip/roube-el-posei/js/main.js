'use strict';
// ===== Roube el Posei 3D - loop principal, HUD e loja =====
const $ = id => document.getElementById(id);

function hud() {
  const p = G.p;
  $('coins').textContent = fmt(save.coins);
  $('lvl').textContent = save.level;
  $('prog').textContent = G.stolenThisLevel + '/' + G.totalThisLevel;
  $('inc').textContent = '+' + incomePerSec().toFixed(1) + '/s';
  $('stamFill').style.width = (p.stamina / maxStamina() * 100) + '%';
  $('shield').textContent = p.shield > 0 ? '🛡️×' + p.shield : '';
  $('shield').style.display = p.shield > 0 ? 'block' : 'none';
  $('boost').textContent = p.boost > 0 ? '⚡' + p.boost.toFixed(0) + 's' : '';
  $('boost').style.display = p.boost > 0 ? 'block' : 'none';
  // aviso central
  const b = $('banner');
  b.textContent = G.banner; b.style.opacity = G.bannerT > 0 ? Math.min(1, G.bannerT) : 0;
  // roubando: barra de progresso
  const gb = $('grabBar');
  gb.style.display = G.grabbing ? 'block' : 'none';
  if (G.grabbing) $('grabFill').style.width = Math.min(100, G.grabT / 0.55 * 100) + '%';
  // vermelho de alerta enquanto carrega alguém
  $('alertFx').style.opacity = G.carrying ? (0.35 + 0.25 * Math.sin(G.time * 8)) : 0;
}

function openShop() {
  $('shop').style.display = 'flex';
  const box = $('shopList'); box.innerHTML = '';
  for (const u of UPGRADES) {
    const lv = save.up[u.id], max = lv >= CFG.maxUp, cost = upCost(u);
    const el = document.createElement('button');
    el.className = 'item'; el.disabled = max || save.coins < cost;
    el.innerHTML = '<b>' + u.n + ' <small>nv ' + lv + '/' + CFG.maxUp + '</small></b><span>' + u.d + '</span><em>' + (max ? 'MÁX' : '🪙 ' + fmt(cost)) + '</em>';
    el.onclick = () => { if (save.coins >= cost && !max) { save.coins -= cost; save.up[u.id]++; persist(); SFX.power(); openShop(); } };
    box.appendChild(el);
  }
  $('shopCoins').textContent = fmt(save.coins);
}
function closeShop() { $('shop').style.display = 'none'; G.p.shield = Math.max(G.p.shield, Math.min(CFG.maxUp, save.up.shield)); G.p.stamina = maxStamina(); }

let last = 0, paused = true;
function loop(ts) {
  const dt = Math.min(0.05, (ts - last) / 1000 || 0); last = ts;
  if (!paused) update(dt); else G.time += dt;
  try { window.R3D.draw(); } catch (e) { showError(e); return; }
  if (!paused) hud();
  requestAnimationFrame(loop);
}

function showError(e) {
  const d = $('err'); d.style.display = 'flex';
  d.querySelector('pre').textContent = String(e && e.stack || e);
}

function boot() {
  loadSave(); setupInput(); buildLevel();
  $('best').textContent = save.best;
  if (!window.R3D) { showError('Falha ao carregar o three.js (vendor/three.module.js). Veja o README.'); return; }
  try { window.R3D.init(); } catch (e) { showError(e); return; }
  $('play').onclick = () => { $('start').style.display = 'none'; paused = false; SFX.level(); };
  $('btnShop').onclick = () => { paused = true; openShop(); };
  $('shopClose').onclick = () => { closeShop(); paused = false; };
  $('btnSound').onclick = () => { soundOn = !soundOn; $('btnSound').textContent = soundOn ? '🔊' : '🔇'; };
  $('reset').onclick = () => { if (confirm('Apagar todo o progresso?')) { localStorage.removeItem(SAVE_KEY); location.reload(); } };
  document.addEventListener('visibilitychange', () => { if (document.hidden) persist(); });
  requestAnimationFrame(loop);
}
window.addEventListener('load', boot);
