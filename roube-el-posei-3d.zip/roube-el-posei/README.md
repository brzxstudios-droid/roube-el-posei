# Roube el Posei 3D 🏝️

Jogo 3D estilo Roblox (personagens de blocos): vá pela reta da ilha, roube pessoas, fuja dos guardas e cruze a linha de chegada 🏁 para garantir no seu cercado. Feito para celular (APK), em modo paisagem.

## Como jogar
- **Joystick** (metade esquerda): andar. **Arraste na direita**: girar a câmera.
- **ROUBAR**: segure perto de uma pessoa até a barra encher.
- **CORRER**: dash (gasta energia, mas faz barulho e os guardas te notam de longe).
- Leve a pessoa até a **linha de chegada** antes de os guardas te pegarem.
- Moedas e renda passiva compram melhorias na 🛒. Pegue ⚡ turbo, 🛡️ escudo e 💰 pela reta; lama deixa lento.
- Mais fases = mais pessoas, mais guardas e mais rápidos. Pessoas mais longe valem mais.

PC: WASD/setas, Espaço = roubar, Shift = correr.

## Gerar o APK (pelo GitHub, sem instalar nada)
1. Crie um repositório e suba **todo o conteúdo desta pasta** (inclusive a pasta oculta `.github`).
2. Aba **Actions → Build APK → Run workflow** (também roda sozinho a cada push).
3. Quando terminar (uns 5–8 min), abra **Releases** do repositório pelo celular, baixe `app-debug.apk` e instale (permita "fontes desconhecidas").
   O APK também fica em *Actions → execução → Artifacts*.

O workflow baixa o three.js (v0.160.0) e embute no APK, então o jogo roda offline.

## Jogar no navegador
Settings → Pages → Source: **GitHub Actions**. O workflow *Publicar jogo* gera o link.

## Testar no PC
```
npm install
npm start
```

O progresso é salvo no aparelho.
